<?php
require_once __DIR__ . '/init.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>School System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
        }
        .navbar {
            background-color: #333;
            color: white;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        .logo {
            font-weight: bold;
            font-size: 18px;
        }
        .nav-right {
            float: right;
        }
        table {
            background-color: white;
            border-collapse: collapse;
            width: 100%;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        input[type="text"], input[type="number"], input[type="date"], select {
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        button, input[type="submit"] {
            background-color: #007bff;
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        button:hover, input[type="submit"]:hover {
            background-color: #0056b3;
        }
        .alert {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 3px;
        }
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-info {
            background-color: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }
        .alert-warning {
            background-color: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }
        h1, h2, h3, h4 {
            color: #333;
        }
        a {
            color: #007bff;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        hr {
            border: 1px solid #ddd;
            margin: 20px 0;
        }
    </style>
</head>
<body>

<!-- NAVBAR -->
<div class="navbar">
    <div class="logo">SchoolSys</div>
    <div class="nav-right">
        <?php if (isset($_SESSION['role'])): ?>
            <span><?php echo ucfirst($_SESSION['role']); ?></span>
        <?php else: ?>
            <span>Guest</span>
        <?php endif; ?>
    </div>
    <div style="clear: both;"></div>
</div>
