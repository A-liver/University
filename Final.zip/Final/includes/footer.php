<div>
<a href="<?php echo $base_url; ?>/auth/logout.php">Logout</a>
</div> <!-- END main-content -->

</body>
</html>