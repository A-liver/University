<?php
require_once __DIR__ . '/init.php';

$base_url = "/final";
?>

<!DOCTYPE html>
<html>
<head>
    <title>School System</title>
    <link rel="stylesheet" href="<?php echo $base_url; ?>/css/style.css">
</head>
<body>

<!-- NAVBAR -->
<div class="navbar">
    <div class="logo">SchoolSys</div>

    <div class="nav-right">

        <?php if (isset($_SESSION['role'])): ?>
            <span><?php echo $_SESSION['role']; ?></span>
        <?php else: ?>
            <span>Guest</span>
        <?php endif; ?>

    </div>
</div>

<!-- SIDEBAR -->
<div class="sidebar">

<?php if (isset($_SESSION['role'])): ?>

    <?php if (($_SESSION['role'] ?? '') == 'admin'): ?>
        <a href="<?php echo $base_url; ?>/admin/admin.php">Dashboard</a>

    <?php elseif (($_SESSION['role'] ?? '') == 'dean'): ?>
        <a href="<?php echo $base_url; ?>/dean/dean_dashboard.php">Dashboard</a>

    <?php elseif (($_SESSION['role'] ?? '') == 'student'): ?>
        <a href="<?php echo $base_url; ?>/student/student_dashboard.php">Dashboard</a>

    <?php elseif (($_SESSION['role'] ?? '') == 'teacher'): ?>
        <a href="<?php echo $base_url; ?>/teacher/teacher_dashboard.php">Dashboard</a>

    <?php elseif (($_SESSION['role'] ?? '') == 'cashier'): ?>
        <a href="<?php echo $base_url; ?>/cashier/cashier_dashboard.php">Dashboard</a>

    <?php elseif (($_SESSION['role'] ?? '') == 'finance'): ?>
        <a href="<?php echo $base_url; ?>/finance/finance_dashboard.php">Dashboard</a>

    <?php elseif (($_SESSION['role'] ?? '') == 'records'): ?>
        <a href="<?php echo $base_url; ?>/records/records_dashboard.php">Dashboard</a>

    <?php endif; ?>

<?php endif; ?>

</div>

<!-- MAIN CONTENT -->
<div class="main-content">