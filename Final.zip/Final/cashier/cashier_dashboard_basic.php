<?php
require_once __DIR__ . '/../includes/header_basic.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'cashier') {
    exit("Access denied");
}

// Get today's collection stats
$todayQuery = mysqli_query($conn, "
    SELECT SUM(amount_paid) as today_total, COUNT(*) as today_count
    FROM payments 
    WHERE DATE(payment_date) = CURDATE()
");
$todayStats = mysqli_fetch_assoc($todayQuery);

// Get monthly collection stats
$monthQuery = mysqli_query($conn, "
    SELECT SUM(amount_paid) as month_total, COUNT(*) as month_count
    FROM payments 
    WHERE MONTH(payment_date) = MONTH(CURDATE()) 
    AND YEAR(payment_date) = YEAR(CURDATE())
");
$monthStats = mysqli_fetch_assoc($monthQuery);
?>

<h1>Cashier Dashboard</h1>
<p>Manage student payments and collections</p>

<hr>

<!-- Statistics -->
<table border="1" cellpadding="10" cellspacing="0" width="100%">
    <tr>
        <td><strong>Today's Collection</strong></td>
        <td><strong>Today's Transactions</strong></td>
        <td><strong>Monthly Collection</strong></td>
        <td><strong>Monthly Transactions</strong></td>
    </tr>
    <tr>
        <td>₱<?= number_format($todayStats['today_total'] ?? 0, 2) ?></td>
        <td><?= $todayStats['today_count'] ?? 0 ?></td>
        <td>₱<?= number_format($monthStats['month_total'] ?? 0, 2) ?></td>
        <td><?= $monthStats['month_count'] ?? 0 ?></td>
    </tr>
</table>

<br>

<!-- Student Search -->
<h2>Student Payment Search</h2>
<form method="POST">
    <input type="text" name="student" placeholder="Student ID / Name / Email" required>
    <button type="submit" name="search">Search Student</button>
</form>

<br>

<?php
if (isset($_POST['search'])) {
    $key = mysqli_real_escape_string($conn, $_POST['student']);
    
    $studentQuery = mysqli_query($conn, "
        SELECT * FROM students
        WHERE student_id = '$key'
           OR email = '$key'
           OR CONCAT(fname,' ',lname) LIKE '%$key%'
           OR fname LIKE '%$key%'
           OR lname LIKE '%$key%'
        LIMIT 1
    ");
    
    $student = mysqli_fetch_assoc($studentQuery);
    
    if (!$student) {
        echo "<p style='color: red;'>Student not found</p>";
    } else {
        $sid = $student['student_id'];
        
        echo "<h3>Student: " . htmlspecialchars($student['fname'] . ' ' . $student['lname']) . "</h3>";
        
        $billingList = mysqli_query($conn, "
            SELECT billing_id, sy, sem, total_amount, status
            FROM billing_master
            WHERE student_id='$sid'
        ");
        
        if (mysqli_num_rows($billingList) == 0) {
            echo "<p>No billing records found for this student.</p>";
        } else {
            echo "<form method='POST'>";
            echo "<input type='hidden' name='sid' value='$sid'>";
            echo "<h4>Select Billing Period:</h4>";
            echo "<select name='billing_id' required>";
            
            while ($b = mysqli_fetch_assoc($billingList)) {
                echo "<option value='{$b['billing_id']}'>
                    {$b['sy']} - Semester {$b['sem']} (₱" . number_format($b['total_amount'], 2) . ") - {$b['status']}
                </option>";
            }
            
            echo "</select>";
            echo "<button type='submit' name='load_billing'>Load Billing</button>";
            echo "</form>";
        }
    }
}
?>

<?php
if (isset($_POST['load_billing'])) {
    $sid = $_POST['sid'];
    $bid = $_POST['billing_id'];
    
    $bm = mysqli_fetch_assoc(mysqli_query($conn, "
        SELECT * FROM billing_master WHERE billing_id='$bid'
    "));
    
    if ($bm) {
        $sy = $bm['sy'];
        $sem = $bm['sem'];
        
        echo "<hr>";
        echo "<h3>Billing Details: $sy - Semester $sem</h3>";
        
        // Get subjects
        $subjects = mysqli_query($conn, "
            SELECT subject_code, units
            FROM student_subjects
            WHERE student_id='$sid' AND sy='$sy' AND sem='$sem'
        ");
        
        $total_units = 0;
        echo "<h4>Enrolled Subjects:</h4>";
        echo "<table border='1' cellpadding='5' cellspacing='0'>";
        echo "<tr><th>Subject</th><th>Units</th></tr>";
        
        while ($s = mysqli_fetch_assoc($subjects)) {
            echo "<tr>
                <td>" . htmlspecialchars($s['subject_code']) . "</td>
                <td>" . $s['units'] . "</td>
            </tr>";
            $total_units += $s['units'];
        }
        
        echo "</table>";
        echo "<p><strong>Total Units: $total_units</strong></p>";
        
        // Get billing details
        $fees = mysqli_query($conn, "
            SELECT * FROM billing_details WHERE billing_id='$bid'
        ");
        
        $total = 0;
        echo "<h4>Fee Breakdown:</h4>";
        echo "<table border='1' cellpadding='5' cellspacing='0'>";
        echo "<tr><th>Description</th><th>Amount</th></tr>";
        
        while ($f = mysqli_fetch_assoc($fees)) {
            echo "<tr>
                <td>" . htmlspecialchars($f['description']) . "</td>
                <td>₱" . number_format($f['amount'], 2) . "</td>
            </tr>";
            $total += $f['amount'];
        }
        
        // Add tuition if no fees found
        if (mysqli_num_rows($fees) == 0) {
            $tuition = $total_units * 300;
            echo "<tr>
                <td>Tuition Fee</td>
                <td>₱" . number_format($tuition, 2) . "</td>
            </tr>";
            $total += $tuition;
        }
        
        echo "</table>";
        
        // Get payments
        $paidQuery = mysqli_query($conn, "
            SELECT SUM(amount_paid) as total FROM payments WHERE billing_id='$bid'
        ");
        $paid = mysqli_fetch_assoc($paidQuery)['total'] ?? 0;
        $balance = $total - $paid;
        
        echo "<h4>Payment Summary:</h4>";
        echo "<table border='1' cellpadding='5' cellspacing='0'>";
        echo "<tr><td>Total Amount:</td><td>₱" . number_format($total, 2) . "</td></tr>";
        echo "<tr><td>Amount Paid:</td><td>₱" . number_format($paid, 2) . "</td></tr>";
        echo "<tr><td><strong>Balance:</strong></td><td><strong>₱" . number_format($balance, 2) . "</strong></td></tr>";
        echo "</table>";
        
        if ($balance > 0) {
            echo "<h4>Process Payment:</h4>";
            echo "<form method='POST'>";
            echo "<input type='hidden' name='billing_id' value='$bid'>";
            echo "<input type='hidden' name='student_id' value='$sid'>";
            echo "Payment Amount: ₱<input type='number' name='amount' step='0.01' min='0.01' max='$balance' required>";
            echo "<button type='submit' name='pay'>Process Payment</button>";
            echo "</form>";
        } else {
            echo "<p style='color: green;'><strong>Fully Paid!</strong></p>";
        }
    }
}
?>

<?php
if (isset($_POST['pay'])) {
    $bid = $_POST['billing_id'];
    $sid = $_POST['student_id'];
    $amount = $_POST['amount'];
    
    $insert = mysqli_query($conn, "
        INSERT INTO payments (billing_id, student_id, amount_paid, payment_date)
        VALUES ('$bid', '$sid', '$amount', NOW())
    ");
    
    if ($insert) {
        $id = mysqli_insert_id($conn);
        echo "<p style='color: green;'><strong>Payment Successful!</strong> Payment of ₱" . number_format($amount, 2) . " has been processed.</p>";
        echo "<a href='receipt.php?id=$id' target='_blank'>🖨️ Print Receipt</a>";
        echo " | <a href=''>🔄 New Transaction</a>";
    } else {
        echo "<p style='color: red;'>Payment error: " . mysqli_error($conn) . "</p>";
    }
}
?>

<br>
<hr>
<h2>Collection Report</h2>
<form method="POST">
    From Date: <input type="date" name="date_from" required>
    To Date: <input type="date" name="date_to" required>
    <button type="submit" name="report">Generate Report</button>
</form>

<?php
if (isset($_POST['report'])) {
    $from = $_POST['date_from'];
    $to = $_POST['date_to'];
    
    echo "<h3>Collection Report: $from to $to</h3>";
    
    $query = mysqli_query($conn, "
        SELECT p.*, s.fname, s.lname
        FROM payments p
        LEFT JOIN students s ON p.student_id = s.student_id
        WHERE DATE(p.payment_date) BETWEEN '$from' AND '$to'
        ORDER BY p.payment_date ASC
    ");
    
    if (!$query) {
        echo "<p style='color: red;'>Report error: " . mysqli_error($conn) . "</p>";
    } else {
        $total = 0;
        
        echo "<table border='1' cellpadding='5' cellspacing='0' width='100%'>";
        echo "<tr><th>Date</th><th>Student</th><th>Amount</th><th>Receipt</th></tr>";
        
        while ($row = mysqli_fetch_assoc($query)) {
            $name = $row['fname'] . " " . $row['lname'];
            $amount = $row['amount_paid'];
            
            echo "<tr>
                <td>" . date('M j, Y', strtotime($row['payment_date'])) . "</td>
                <td>" . htmlspecialchars($name) . "</td>
                <td>₱" . number_format($amount, 2) . "</td>
                <td><a href='receipt.php?id={$row['id']}'>Receipt</a></td>
            </tr>";
            
            $total += $amount;
        }
        
        echo "</table>";
        echo "<h3>Total Collection: ₱" . number_format($total, 2) . "</h3>";
    }
}
?>

<br>
<hr>
<p><a href="student_billing_basic.php">Student Billing</a> | <a href="../auth/logout.php">Logout</a></p>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
