<?php
require_once __DIR__ . '/../includes/header_basic.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'cashier') {
    exit("Access denied");
}

// Handle student search
$student = null;
$billingRecords = null;
$message = '';

if (isset($_POST['search'])) {
    $searchTerm = mysqli_real_escape_string($conn, $_POST['student']);
    
    // Simple student search
    $studentQuery = mysqli_query($conn, "
        SELECT * FROM students 
        WHERE student_id = '$searchTerm' 
        OR fname LIKE '%$searchTerm%' 
        OR lname LIKE '%$searchTerm%'
        LIMIT 1
    ");
    
    if ($studentQuery && mysqli_num_rows($studentQuery) > 0) {
        $student = mysqli_fetch_assoc($studentQuery);
        
        // Get billing records for this student
        $billingQuery = mysqli_query($conn, "
            SELECT * FROM billing_master 
            WHERE student_id = '{$student['student_id']}'
            ORDER BY sy DESC, sem DESC
        ");
        
        if ($billingQuery) {
            $billingRecords = [];
            while ($row = mysqli_fetch_assoc($billingQuery)) {
                $billingRecords[] = $row;
            }
        }
        
        $message = "Student found: " . htmlspecialchars($student['fname'] . ' ' . $student['lname']);
    } else {
        $message = "Student not found. Please try a different search term.";
    }
}

// Handle billing selection
$selectedBilling = null;
if (isset($_POST['select_billing']) && isset($_POST['billing_id'])) {
    $billingId = mysqli_real_escape_string($conn, $_POST['billing_id']);
    $billingQuery = mysqli_query($conn, "
        SELECT * FROM billing_master WHERE billing_id = '$billingId'
    ");
    
    if ($billingQuery) {
        $selectedBilling = mysqli_fetch_assoc($billingQuery);
    }
}

// Handle payment
if (isset($_POST['process_payment'])) {
    $billingId = mysqli_real_escape_string($conn, $_POST['billing_id']);
    $studentId = mysqli_real_escape_string($conn, $_POST['student_id']);
    $amount = mysqli_real_escape_string($conn, $_POST['payment_amount']);
    
    // Insert payment
    $insertQuery = mysqli_query($conn, "
        INSERT INTO payments (billing_id, student_id, amount_paid, payment_date)
        VALUES ('$billingId', '$studentId', '$amount', NOW())
    ");
    
    if ($insertQuery) {
        $message = "Payment of ₱$amount processed successfully!";
        // Clear selection
        $selectedBilling = null;
    } else {
        $message = "Payment failed: " . mysqli_error($conn);
    }
}
?>

<h1>Student Billing</h1>
<p>Search students and process payments</p>
<p><a href="cashier_dashboard_basic.php">← Back to Dashboard</a></p>

<hr>

<?php if ($message): ?>
    <p style="color: blue; font-weight: bold;"><?= htmlspecialchars($message) ?></p>
    <hr>
<?php endif; ?>

<!-- Search Form -->
<h2>Search Student</h2>
<form method="POST">
    <table border="0" cellpadding="5">
        <tr>
            <td>Student Search:</td>
            <td><input type="text" name="student" placeholder="Enter Student ID, First Name, or Last Name" required></td>
            <td><button type="submit" name="search">Search</button></td>
        </tr>
    </table>
</form>

<br>

<!-- Student Information -->
<?php if ($student): ?>
    <h2>Student Information</h2>
    <table border="1" cellpadding="5" cellspacing="0">
        <tr>
            <td><strong>Student ID</strong></td>
            <td><?= $student['student_id'] ?></td>
            <td><strong>Name</strong></td>
            <td><?= htmlspecialchars($student['lname'] . ', ' . $student['fname']) ?></td>
        </tr>
        <tr>
            <td><strong>Course</strong></td>
            <td><?= htmlspecialchars($student['course'] ?? 'N/A') ?></td>
            <td><strong>Email</strong></td>
            <td><?= htmlspecialchars($student['email'] ?? 'N/A') ?></td>
        </tr>
    </table>

    <br>

    <!-- Billing Records -->
    <h2>Billing Records</h2>
    <?php if ($billingRecords && count($billingRecords) > 0): ?>
        <form method="POST">
            <input type="hidden" name="student_id" value="<?= $student['student_id'] ?>">
            <table border="1" cellpadding="5" cellspacing="0">
                <tr>
                    <th>School Year</th>
                    <th>Semester</th>
                    <th>Total Amount</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
                <?php foreach ($billingRecords as $billing): ?>
                    <tr>
                        <td><?= htmlspecialchars($billing['sy']) ?></td>
                        <td><?= htmlspecialchars($billing['sem']) ?></td>
                        <td>₱<?= number_format($billing['total_amount'], 2) ?></td>
                        <td><?= ucfirst($billing['status']) ?></td>
                        <td>
                            <button type="submit" name="select_billing" value="<?= $billing['billing_id'] ?>">
                                View Details
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </form>
    <?php else: ?>
        <p style="color: orange;">No billing records found for this student.</p>
    <?php endif; ?>
<?php endif; ?>

<!-- Billing Details -->
<?php if ($selectedBilling): ?>
    <?php
    // Get payment history
    $paymentsQuery = mysqli_query($conn, "
        SELECT * FROM payments 
        WHERE billing_id = '{$selectedBilling['billing_id']}'
        ORDER BY payment_date DESC
    ");
    
    $totalPaid = 0;
    $payments = [];
    if ($paymentsQuery) {
        while ($row = mysqli_fetch_assoc($paymentsQuery)) {
            $payments[] = $row;
            $totalPaid += $row['amount_paid'];
        }
    }
    
    $balance = $selectedBilling['total_amount'] - $totalPaid;
    ?>
    
    <hr>
    <h2>Billing Details - <?= $selectedBilling['sy'] ?> Semester <?= $selectedBilling['sem'] ?></h2>
    
    <!-- Summary -->
    <table border="1" cellpadding="10" cellspacing="0">
        <tr>
            <td><strong>Total Amount:</strong></td>
            <td>₱<?= number_format($selectedBilling['total_amount'], 2) ?></td>
            <td><strong>Amount Paid:</strong></td>
            <td>₱<?= number_format($totalPaid, 2) ?></td>
            <td><strong>Balance:</strong></td>
            <td><strong>₱<?= number_format($balance, 2) ?></strong></td>
        </tr>
    </table>

    <br>

    <!-- Payment Form -->
    <?php if ($balance > 0): ?>
        <h3>Process Payment</h3>
        <form method="POST">
            <input type="hidden" name="billing_id" value="<?= $selectedBilling['billing_id'] ?>">
            <input type="hidden" name="student_id" value="<?= $student['student_id'] ?>">
            <table border="0" cellpadding="5">
                <tr>
                    <td>Payment Amount (₱):</td>
                    <td><input type="number" name="payment_amount" step="0.01" min="0.01" max="<?= $balance ?>" required></td>
                    <td><small>Maximum: ₱<?= number_format($balance, 2) ?></small></td>
                </tr>
                <tr>
                    <td colspan="3"><button type="submit" name="process_payment">Process Payment</button></td>
                </tr>
            </table>
        </form>
    <?php else: ?>
        <p style="color: green;"><strong>Fully Paid!</strong> This billing has been completely paid.</p>
    <?php endif; ?>

    <!-- Payment History -->
    <?php if (!empty($payments)): ?>
        <br>
        <h3>Payment History</h3>
        <table border="1" cellpadding="5" cellspacing="0">
            <tr>
                <th>Date</th>
                <th>Amount</th>
                <th>Receipt</th>
            </tr>
            <?php foreach ($payments as $payment): ?>
                <tr>
                    <td><?= date('M d, Y h:i A', strtotime($payment['payment_date'])) ?></td>
                    <td>₱<?= number_format($payment['amount_paid'], 2) ?></td>
                    <td><a href="receipt.php?id=<?= $payment['id'] ?>" target="_blank">Receipt</a></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
<?php endif; ?>

<br>
<hr>
<p><a href="../auth/logout.php">Logout</a></p>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
