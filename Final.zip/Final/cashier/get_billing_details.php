<?php
require_once __DIR__ . '/../includes/init.php';

header('Content-Type: text/html');

$billingId = mysqli_real_escape_string($conn, $_GET['id']);

// Get billing master info
$billing = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT bm.*, s.fname, s.lname 
    FROM billing_master bm
    JOIN students s ON s.student_id = bm.student_id
    WHERE bm.billing_id='$billingId'
"));

if (!$billing) {
    echo "<div class='alert alert-error'>Billing not found.</div>";
    exit;
}

$sid = $billing['student_id'];
$sy = $billing['sy'];
$sem = $billing['sem'];

// Get enrolled subjects
$subjects = mysqli_query($conn, "
    SELECT subject_code, units
    FROM student_subjects
    WHERE student_id='$sid' AND sy='$sy' AND sem='$sem'
");

$totalUnits = 0;
while ($s = mysqli_fetch_assoc($subjects)) {
    $totalUnits += $s['units'];
}
mysqli_data_seek($subjects, 0);

// Get billing details
$details = mysqli_query($conn, "
    SELECT * FROM billing_details WHERE billing_id='$billingId'
");

// Get payments
$payments = mysqli_query($conn, "
    SELECT * FROM payments WHERE billing_id='$billingId' ORDER BY payment_date DESC
");

$totalPaid = 0;
while ($p = mysqli_fetch_assoc($payments)) {
    $totalPaid += $p['amount_paid'];
}
mysqli_data_seek($payments, 0);

$balance = $billing['total_amount'] - $totalPaid;
?>

<div class="billing-details">
    <div class="mb-4">
        <h4>📋 Billing Information</h4>
        <div class="grid grid-cols-2 gap-4">
            <div>
                <strong>Student:</strong> <?= htmlspecialchars($billing['fname'] . ' ' . $billing['lname']) ?><br>
                <strong>School Year:</strong> <?= htmlspecialchars($billing['sy']) ?><br>
                <strong>Semester:</strong> <?= htmlspecialchars($billing['sem']) ?>
            </div>
            <div>
                <strong>Total Units:</strong> <?= $totalUnits ?><br>
                <strong>Total Amount:</strong> ₱<?= number_format($billing['total_amount'], 2) ?><br>
                <strong>Status:</strong> <span class="badge badge-<?= $billing['status'] == 'paid' ? 'success' : ($billing['status'] == 'partial' ? 'warning' : 'danger') ?>"><?= ucfirst($billing['status']) ?></span>
            </div>
        </div>
    </div>

    <div class="mb-4">
        <h4>📚 Enrolled Subjects</h4>
        <table class="table">
            <thead>
                <tr><th>Subject Code</th><th>Units</th></tr>
            </thead>
            <tbody>
                <?php mysqli_data_seek($subjects, 0); ?>
                <?php while ($s = mysqli_fetch_assoc($subjects)): ?>
                    <tr>
                        <td><?= htmlspecialchars($s['subject_code']) ?></td>
                        <td><span class="badge badge-info"><?= $s['units'] ?></span></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <div class="mb-4">
        <h4>💰 Fee Breakdown</h4>
        <table class="table">
            <thead>
                <tr><th>Fee Name</th><th>Amount</th></tr>
            </thead>
            <tbody>
                <?php 
                $detailsCount = 0;
                while ($d = mysqli_fetch_assoc($details)): 
                    $detailsCount++;
                ?>
                    <tr>
                        <td><?= htmlspecialchars($d['description'] ?? 'Fee ' . $detailsCount) ?></td>
                        <td>₱<?= number_format($d['amount'] ?? 0, 2) ?></td>
                    </tr>
                <?php endwhile; ?>
                
                if ($detailsCount == 0):
                ?>
                    <tr>
                        <td>Tuition Fee</td>
                        <td>₱<?= number_format($totalUnits * 300, 2) ?></td>
                    </tr>
                    <tr>
                        <td>Registration Fee</td>
                        <td>₱500.00</td>
                    </tr>
                    <tr>
                        <td>Library Fee</td>
                        <td>₱200.00</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mb-4">
        <h4>💳 Payment History</h4>
        <table class="table">
            <thead>
                <tr><th>Date</th><th>Amount</th><th>Receipt</th></tr>
            </thead>
            <tbody>
                <?php mysqli_data_seek($payments, 0); ?>
                <?php while ($p = mysqli_fetch_assoc($payments)): ?>
                    <tr>
                        <td><?= date('M d, Y h:i A', strtotime($p['payment_date'])) ?></td>
                        <td>₱<?= number_format($p['amount_paid'], 2) ?></td>
                        <td><a href="receipt.php?id=<?= $p['id'] ?>" class="btn btn-outline btn-sm" target="_blank">🧾 Receipt</a></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <div class="grid grid-cols-3 gap-4">
        <div class="text-center p-3 border rounded">
            <strong>Total Amount:</strong><br>
            <span class="text-primary">₱<?= number_format($billing['total_amount'], 2) ?></span>
        </div>
        <div class="text-center p-3 border rounded">
            <strong>Amount Paid:</strong><br>
            <span class="text-success">₱<?= number_format($totalPaid, 2) ?></span>
        </div>
        <div class="text-center p-3 border rounded">
            <strong>Balance:</strong><br>
            <span class="text-danger">₱<?= number_format($balance, 2) ?></span>
        </div>
    </div>
</div>

<style>
.billing-details {
    padding: 20px;
}

.table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 15px;
}

.table th, .table td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}

.table th {
    background-color: #f2f2f2;
}

.badge {
    padding: 2px 6px;
    border-radius: 3px;
    font-size: 12px;
}

.badge-success { background-color: #28a745; color: white; }
.badge-warning { background-color: #ffc107; color: black; }
.badge-danger { background-color: #dc3545; color: white; }
.badge-info { background-color: #17a2b8; color: white; }
.badge-primary { background-color: #007bff; color: white; }

.text-primary { color: #007bff; }
.text-success { color: #28a745; }
.text-danger { color: #dc3545; }

.btn {
    padding: 4px 8px;
    border: 1px solid #ccc;
    background-color: white;
    text-decoration: none;
    border-radius: 3px;
    font-size: 12px;
}

.btn-outline {
    border-color: #007bff;
    color: #007bff;
}

.btn-outline:hover {
    background-color: #007bff;
    color: white;
}
</style>
