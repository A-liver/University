<h3>Cash Collection Report</h3>

<form method="POST">
    From: <input type="date" name="from" required>
    To: <input type="date" name="to" required>
    <button name="report">Generate</button>
</form>

<?php
if (isset($_POST['report'])) {

    $from = $_POST['from'];
    $to = $_POST['to'];

    $res = mysqli_query($conn, "
        SELECT * FROM payments 
        WHERE DATE(payment_date) BETWEEN '$from' AND '$to'
    ");

    $total = 0;

    echo "<table border='1'><tr><th>ID</th><th>Student</th><th>Amount</th><th>Date</th></tr>";

    while ($r = mysqli_fetch_assoc($res)) {
        echo "<tr>
                <td>{$r['id']}</td>
                <td>{$r['student_id']}</td>
                <td>{$r['amount']}</td>
                <td>{$r['payment_date']}</td>
              </tr>";
        $total += $r['amount'];
    }

    echo "</table>";
    echo "TOTAL COLLECTION: $total";
}
?>