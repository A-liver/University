<?php
require_once __DIR__ . '/../config/db_connection.php';

$db = new Database();
$conn = $db->getConnection();

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid receipt ID.");
}

$id = intval($_GET['id']);

/* GET PAYMENT + STUDENT + BILLING INFO */
$query = mysqli_query($conn, "
    SELECT 
        p.*,
        s.fname,
        s.lname,
        s.student_id,
        s.course,
        b.sy,
        b.sem,
        b.total_amount
    FROM payments p
    LEFT JOIN students s 
        ON p.student_id = s.student_id
    LEFT JOIN billing_master b 
        ON p.billing_id = b.billing_id
    WHERE p.payment_id = '$id'
");

if (!$query) {
    die("SQL Error: " . mysqli_error($conn));
}

$p = mysqli_fetch_assoc($query);

/* TOTAL PAID */
$paidQuery = mysqli_query($conn, "
    SELECT SUM(amount_paid) as total_paid
    FROM payments
    WHERE billing_id = '{$p['billing_id']}'
");

$totalPaid = mysqli_fetch_assoc($paidQuery)['total_paid'] ?? 0;

/* BALANCE */
$balance = $p['total_amount'] - $totalPaid;

/* GET BILLING DETAILS */
$billingDetails = mysqli_query($conn, "
    SELECT *
    FROM billing_details
    WHERE billing_id = '{$p['billing_id']}'
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>
    Official Receipt #<?= str_pad($p['id'], 6, '0', STR_PAD_LEFT) ?>
</title>

<style>
    *{
        margin:0;
        padding:0;
        box-sizing:border-box;
    }

    body{
        font-family:'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        background:linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding:20px;
        color:#222;
    }

    .receipt{
        max-width:800px;
        margin:auto;
        background:#fff;
        padding:40px;
        border-radius:1rem;
        box-shadow:0 10px 30px rgba(0,0,0,0.1);
        border:1px solid #e2e8f0;
        position:relative;
        overflow:hidden;
    }

    .receipt::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: linear-gradient(90deg, #2563eb, #1e40af);
    }

    .header{
        text-align:center;
        border-bottom:3px double #2563eb;
        padding-bottom:15px;
        margin-bottom:25px;
        position:relative;
    }

    .header h1{
        font-size:32px;
        margin-bottom:5px;
        background: linear-gradient(135deg, #2563eb, #1e40af);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-weight:700;
    }

    .header .subtitle {
        color:#64748b;
        font-size:14px;
        margin-top:5px;
    }

    .header p{
        font-size:14px;
        color:#666;
    }

    .info-grid{
        display:grid;
        grid-template-columns:1fr 1fr;
        gap:15px;
        margin-bottom:25px;
    }

    .info-box{
        border:1px solid #ddd;
        padding:10px;
        border-radius:5px;
    }

    .label{
        font-size:12px;
        color:#777;
        margin-bottom:5px;
        text-transform:uppercase;
    }

    .value{
        font-weight:bold;
    }

    table{
        width:100%;
        border-collapse:collapse;
        margin-top:15px;
    }

    table th{
        background:#f0f0f0;
        border:1px solid #ccc;
        padding:10px;
        text-align:left;
    }

    table td{
        border:1px solid #ccc;
        padding:10px;
    }

    .text-right{
        text-align:right;
    }

    .summary{
        margin-top:25px;
    }

    .summary-row{
        display:flex;
        justify-content:space-between;
        padding:10px 0;
        border-bottom:1px dashed #ccc;
    }

    .summary-row.total{
        font-size:22px;
        font-weight:bold;
        color:green;
        border:none;
    }

    .footer{
        margin-top:50px;
        text-align:center;
        font-size:13px;
        color:#666;
    }

    .signatures{
        display:flex;
        justify-content:space-between;
        margin-top:60px;
    }

    .signature-box{
        width:220px;
        text-align:center;
    }

    .signature-line{
        border-top:1px solid #000;
        margin-bottom:5px;
        padding-top:5px;
    }

    @media print{
        body{
            background:#fff;
            padding:0;
        }

        .receipt{
            border:none;
            box-shadow:none;
        }
    }
</style>
</head>

<body>

<div class="receipt">

    <div class="header">
        <h1>OFFICIAL RECEIPT</h1>
        <p>University Management System</p>
    </div>

    <div class="info-grid">

        <div class="info-box">
            <div class="label">Receipt Number</div>
            <div class="value">
                #<?= str_pad($p['payment_id'], 6, '0', STR_PAD_LEFT) ?>
            </div>
        </div>

        <div class="info-box">
            <div class="label">Payment Date</div>
            <div class="value">
                <?= date('F d, Y h:i A', strtotime($p['payment_date'])) ?>
            </div>
        </div>

        <div class="info-box">
            <div class="label">Student ID</div>
            <div class="value">
                <?= htmlspecialchars($p['student_id']) ?>
            </div>
        </div>

        <div class="info-box">
            <div class="label">Student Name</div>
            <div class="value">
                <?= htmlspecialchars($p['fname'] . ' ' . $p['lname']) ?>
            </div>
        </div>

        <div class="info-box">
            <div class="label">Course</div>
            <div class="value">
                <?= htmlspecialchars($p['course']) ?>
            </div>
        </div>

        <div class="info-box">
            <div class="label">Billing Period</div>
            <div class="value">
                <?= htmlspecialchars($p['sy']) ?> - Semester <?= htmlspecialchars($p['sem']) ?>
            </div>
        </div>

    </div>

    <h3>Fee Breakdown</h3>

    <table>
        <thead>
            <tr>
                <th>Description</th>
                <th>Category</th>
                <th class="text-right">Amount</th>
            </tr>
        </thead>

        <tbody>

        <?php
        if (mysqli_num_rows($billingDetails) > 0):

            while ($d = mysqli_fetch_assoc($billingDetails)):
        ?>

            <tr>
                <td>
                    <?= htmlspecialchars($d['fee_name'] ?? 'Fee') ?>
                </td>

                <td>
                    <?= htmlspecialchars($d['category'] ?? 'General') ?>
                </td>

                <td class="text-right">
                    ₱<?= number_format($d['amount'] ?? 0, 2) ?>
                </td>
            </tr>

        <?php
            endwhile;

        else:
        ?>

            <tr>
                <td>Tuition and Miscellaneous Fees</td>
                <td>General</td>
                <td class="text-right">
                    ₱<?= number_format($p['total_amount'], 2) ?>
                </td>
            </tr>

        <?php endif; ?>

        </tbody>
    </table>

    <div class="summary">

        <div class="summary-row">
            <span>Total Billing Amount</span>
            <strong>
                ₱<?= number_format($p['total_amount'], 2) ?>
            </strong>
        </div>

        <div class="summary-row">
            <span>Total Paid</span>
            <strong>
                ₱<?= number_format($totalPaid, 2) ?>
            </strong>
        </div>

        <div class="summary-row">
            <span>Remaining Balance</span>
            <strong>
                ₱<?= number_format($balance, 2) ?>
            </strong>
        </div>

        <div class="summary-row total">
            <span>Payment Received</span>
            <span>
                ₱<?= number_format($p['amount_paid'], 2) ?>
            </span>
        </div>

    </div>

    <div class="signatures">

        <div class="signature-box">
            <div class="signature-line"></div>
            <small>Cashier Signature</small>
        </div>

        <div class="signature-box">
            <div class="signature-line"></div>
            <small>Student Signature</small>
        </div>

    </div>

    <div class="footer">
        Generated on <?= date('F d, Y h:i:s A') ?><br>
        Receipt ID #<?= str_pad($p['payment_id'], 6, '0', STR_PAD_LEFT) ?>
    </div>

</div>

<script>
window.onload = function () {
    window.print();
};
</script>

</body>
</html>