<?php
require_once __DIR__ . '/../config/db_connection.php';

$db = new Database();
$conn = $db->getConnection();

$id = intval($_GET['id']);

/* GET PAYMENT */
$p = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT * FROM payments WHERE payment_id='$id'
"));

if (!$p) {
    die("Receipt not found");
}

echo "<h2>OFFICIAL RECEIPT</h2>";
echo "Receipt #: {$p['payment_id']} <br>";
echo "Student ID: {$p['student_id']} <br>";
echo "Billing ID: {$p['billing_id']} <br>";
echo "Amount Paid: ₱{$p['amount_paid']} <br>";
echo "Date: {$p['payment_date']} <br>";

echo "<script>window.print();</script>";
?>