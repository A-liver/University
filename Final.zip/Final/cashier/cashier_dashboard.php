<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'cashier') {
    exit("Access denied");
}

// Get today's collection stats
$todayQuery = mysqli_query($conn, "
    SELECT SUM(amount_paid) as today_total, COUNT(*) as today_count
    FROM payments 
    WHERE DATE(payment_date) = CURDATE()
");
$todayStats = mysqli_fetch_assoc($todayQuery);

// Get monthly collection stats
$monthQuery = mysqli_query($conn, "
    SELECT SUM(amount_paid) as month_total, COUNT(*) as month_count
    FROM payments 
    WHERE MONTH(payment_date) = MONTH(CURDATE()) 
    AND YEAR(payment_date) = YEAR(CURDATE())
");
$monthStats = mysqli_fetch_assoc($monthQuery);

// Get today's payment details for quick view
$todayPayments = mysqli_query($conn, "
    SELECT p.*, s.fname, s.lname 
    FROM payments p
    LEFT JOIN students s ON s.student_id = p.student_id
    WHERE DATE(p.payment_date) = CURDATE()
    ORDER BY p.payment_date DESC
    LIMIT 5
");
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 style="font-size: 2rem; font-weight: 700; background: linear-gradient(135deg, var(--primary-color), var(--primary-dark)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                <i class="fas fa-cash-register"></i> Cashier Dashboard
            </h1>
            <p class="text-secondary">Payment processing and collection management</p>
        </div>
        <div class="flex gap-2">
            <a href="student_billing.php" class="btn btn-primary">
                <i class="fas fa-user-graduate"></i> Student Billing
            </a>
            <a href="collection_report.php" class="btn btn-secondary">
                <i class="fas fa-chart-line"></i> Collection Report
            </a>
            <a href="../auth/logout.php" class="btn btn-outline">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="stats-grid mb-6">
        <div class="stat-card">
            <div class="stat-value">₱<?= number_format($todayStats['today_total'] ?? 0, 2) ?></div>
            <div class="stat-label">Today's Collection</div>
        </div>
        <div class="stat-card success">
            <div class="stat-value"><?= $todayStats['today_count'] ?? 0 ?></div>
            <div class="stat-label">Today's Transactions</div>
        </div>
        <div class="stat-card warning">
            <div class="stat-value">₱<?= number_format($monthStats['month_total'] ?? 0, 2) ?></div>
            <div class="stat-label">Monthly Collection</div>
        </div>
        <div class="stat-card danger">
            <div class="stat-value"><?= $monthStats['month_count'] ?? 0 ?></div>
            <div class="stat-label">Monthly Transactions</div>
        </div>
    </div>

    <!-- Student Search -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-search"></i> Student Search
            </h2>
            <p class="text-sm text-secondary">Search students by ID, name, or email</p>
        </div>
        <div class="card-body">
            <form method="POST" class="flex gap-4">
                <div class="flex-1">
                    <label class="form-label">Student Information</label>
                    <input type="text" name="student" class="form-input" placeholder="Enter Student ID, Name, or Email..." required>
                </div>
                <div class="flex items-end">
                    <button type="submit" name="search" class="btn btn-primary">
                        <i class="fas fa-search"></i> Search Student
                    </button>
                </div>
            </form>
        </div>
    </div>

    <?php
    if (isset($_POST['search'])) {
        $key = mysqli_real_escape_string($conn, $_POST['student']);
        
        $studentQuery = mysqli_query($conn, "
            SELECT * FROM students
            WHERE student_id = '$key'
               OR email = '$key'
               OR CONCAT(fname,' ',lname) LIKE '%$key%'
               OR fname LIKE '%$key%'
               OR lname LIKE '%$key%'
            LIMIT 1
        ");
        
        if ($studentQuery && mysqli_num_rows($studentQuery) > 0) {
            $student = mysqli_fetch_assoc($studentQuery);
            // Redirect to student details page
            echo "<script>window.location.href='student_details.php?id={$student['student_id']}';</script>";
        } else {
            echo "<div class='alert alert-error'>Student not found. Please check the Student ID, name, or email.</div>";
        }
    }
    ?>
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-bolt"></i> Quick Actions
            </h2>
            <p class="text-sm text-secondary">Frequently used functions</p>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <a href="student_billing.php" class="btn btn-primary">
                    <i class="fas fa-user-graduate"></i> Student Billing
                </a>
                <a href="collection_report.php" class="btn btn-secondary">
                    <i class="fas fa-chart-line"></i> Collection Report
                </a>
                <button onclick="window.print()" class="btn btn-outline">
                    <i class="fas fa-print"></i> Print Dashboard
                </button>
                <a href="../auth/logout.php" class="btn btn-danger">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>
    </div>

    <!-- Today's Recent Transactions -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-clock"></i> Today's Recent Transactions
            </h2>
            <p class="text-sm text-secondary">Latest payment transactions today</p>
        </div>
        <div class="card-body">
            <?php if (mysqli_num_rows($todayPayments) > 0): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th><i class="fas fa-clock"></i> Time</th>
                                <th><i class="fas fa-user"></i> Student</th>
                                <th><i class="fas fa-money-bill"></i> Amount</th>
                                <th><i class="fas fa-receipt"></i> Receipt</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($payment = mysqli_fetch_assoc($todayPayments)): ?>
                                <tr>
                                    <td>
                                        <span class="badge badge-info"><?= date('h:i A', strtotime($payment['payment_date'])) ?></span>
                                    </td>
                                    <td>
                                        <div class="font-semibold"><?= htmlspecialchars($payment['fname'] . ' ' . $payment['lname']) ?></div>
                                    </td>
                                    <td>
                                        <span class="badge badge-success">₱<?= number_format($payment['amount_paid'], 2) ?></span>
                                    </td>
                                    <td>
                                        <a href="receipt.php?id=<?= $payment['payment_id'] ?>" class="btn btn-outline btn-sm" target="_blank">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> <strong>No transactions today.</strong> Start processing student payments to see them here.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Important Information -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-info-circle"></i> Important Information
            </h2>
            <p class="text-sm text-secondary">Guidelines and procedures for cashier operations</p>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <h4 class="font-semibold mb-3 text-blue-800">
                        <i class="fas fa-clipboard-list"></i> Daily Procedures:
                    </h4>
                    <ul class="space-y-2 text-sm text-blue-700">
                        <li><i class="fas fa-check-circle"></i> Process all student payments accurately</li>
                        <li><i class="fas fa-check-circle"></i> Issue receipts for every transaction</li>
                        <li><i class="fas fa-check-circle"></i> Verify student billing information</li>
                        <li><i class="fas fa-check-circle"></i> Generate end-of-day reports</li>
                    </ul>
                </div>
                <div class="bg-green-50 p-4 rounded-lg border border-green-200">
                    <h4 class="font-semibold mb-3 text-green-800">
                        <i class="fas fa-credit-card"></i> Payment Guidelines:
                    </h4>
                    <ul class="space-y-2 text-sm text-green-700">
                        <li><i class="fas fa-check-circle"></i> Accept cash and check payments</li>
                        <li><i class="fas fa-check-circle"></i> Record payment details immediately</li>
                        <li><i class="fas fa-check-circle"></i> Provide printed receipts</li>
                        <li><i class="fas fa-check-circle"></i> Handle payment inquiries professionally</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>