<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'cashier') {
    exit("Access denied");
}
?>

<h2>Cashier Dashboard</h2>

<!-- SEARCH -->
<form method="POST">
    <input type="text" name="student" placeholder="Student ID / Name / Email" required>
    <button name="search">Search</button>
</form>

<hr>

<h3>Cash Collection Report</h3>

<form method="POST">
    <label>From:</label>
    <input type="date" name="date_from" required>

    <label>To:</label>
    <input type="date" name="date_to" required>

    <button name="report">Generate Report</button>
</form>

<hr>

<?php

/* =========================
   CASH COLLECTION REPORT
========================= */
if (isset($_POST['report'])) {

    $from = $_POST['date_from'];
    $to   = $_POST['date_to'];

    echo "<h3>Collection Report: $from to $to</h3>";

    $query = mysqli_query($conn, "
        SELECT p.*, s.fname, s.lname
        FROM payments p
        LEFT JOIN students s ON p.student_id = s.student_id
        WHERE DATE(p.payment_date) BETWEEN '$from' AND '$to'
        ORDER BY p.payment_date ASC
    ");

    if (!$query) {
        die("Report error: " . mysqli_error($conn));
    }

    $total = 0;

    echo "<table border='1'>
        <tr>
            <th>Date</th>
            <th>Student</th>
            <th>Amount</th>
        </tr>";

    while ($row = mysqli_fetch_assoc($query)) {

        $name = $row['fname'] . " " . $row['lname'];
        $amount = $row['amount_paid'];

        echo "<tr>
            <td>{$row['payment_date']}</td>
            <td>{$name}</td>
            <td>{$amount}</td>
        </tr>";

        $total += $amount;
    }

    echo "</table>";
    echo "<h3>Total Collection: $total</h3>";
}

/* =========================
   SEARCH STUDENT
========================= */
if (isset($_POST['search'])) {

    $key = mysqli_real_escape_string($conn, $_POST['student']);

    $studentQuery = mysqli_query($conn, "
        SELECT * FROM students
        WHERE student_id = '$key'
           OR email = '$key'
           OR CONCAT(fname,' ',lname) LIKE '%$key%'
           OR fname LIKE '%$key%'
           OR lname LIKE '%$key%'
        LIMIT 1
    ");

    $student = mysqli_fetch_assoc($studentQuery);

    if (!$student) {
        exit("Student not found");
    }

    $sid = $student['student_id'];

    echo "<h3>{$student['fname']} {$student['lname']}</h3>";

    $billingList = mysqli_query($conn, "
        SELECT billing_id, sy, sem
        FROM billing_master
        WHERE student_id='$sid'
    ");

    if (mysqli_num_rows($billingList) == 0) {
        exit("No billing found.");
    }

    echo "<form method='POST'>";
    echo "<input type='hidden' name='sid' value='$sid'>";

    echo "<select name='billing_id' required>";

    while ($b = mysqli_fetch_assoc($billingList)) {
        echo "<option value='{$b['billing_id']}'>
            {$b['sy']} - {$b['sem']}
        </option>";
    }

    echo "</select>";
    echo "<button name='load_billing'>Load</button>";
    echo "</form>";
}

/* =========================
   LOAD BILLING
========================= */
if (isset($_POST['load_billing'])) {

    $sid = $_POST['sid'];
    $bid = $_POST['billing_id'];

    $bm = mysqli_fetch_assoc(mysqli_query($conn, "
        SELECT * FROM billing_master
        WHERE billing_id='$bid'
    "));

    if (!$bm) exit("Billing not found");

    $sy = $bm['sy'];
    $sem = $bm['sem'];

    echo "<h3>Billing: $sy - $sem</h3>";

    /* SUBJECTS */
    $subjects = mysqli_query($conn, "
        SELECT subject_code, units
        FROM student_subjects
        WHERE student_id='$sid'
        AND sy='$sy'
        AND sem='$sem'
    ");

    $total_units = 0;

    echo "<table border='1'>
        <tr><th>Subject</th><th>Units</th></tr>";

    while ($s = mysqli_fetch_assoc($subjects)) {
        $total_units += $s['units'];

        echo "<tr>
            <td>{$s['subject_code']}</td>
            <td>{$s['units']}</td>
        </tr>";
    }

    echo "</table>";

    /* FEES */
    $fees = mysqli_query($conn, "
        SELECT description, amount
        FROM billing_details
        WHERE billing_id='$bid'
    ");

    $total = 0;

    echo "<table border='1'>
        <tr><th>Description</th><th>Amount</th></tr>";

    while ($f = mysqli_fetch_assoc($fees)) {
        echo "<tr>
            <td>{$f['description']}</td>
            <td>{$f['amount']}</td>
        </tr>";

        $total += $f['amount'];
    }

    echo "</table>";

    /* TUITION */
    $tuition = ($total_units / 3) * 300;
    $total += $tuition;

    echo "<h4>Tuition: $tuition</h4>";

    /* PAYMENTS */
    $paidRow = mysqli_fetch_assoc(mysqli_query($conn, "
        SELECT SUM(amount_paid) AS total
        FROM payments
        WHERE billing_id='$bid'
    "));

    $paid = $paidRow['total'] ?? 0;
    $balance = $total - $paid;

    /* STATUS (FIXED: USE COMPUTED TOTAL) */
    if ($paid <= 0) {
        $status = 'unpaid';
    } elseif ($paid < $total) {
        $status = 'partial';
    } else {
        $status = 'paid';
    }

    mysqli_query($conn, "
        UPDATE billing_master
        SET total_units='$total_units',
            total_amount='$total',
            status='$status'
        WHERE billing_id='$bid'
    ");

    echo "<h3>Total: $total</h3>";
    echo "<h3>Paid: $paid</h3>";
    echo "<h3>Balance: $balance</h3>";
    echo "<h3>Status: $status</h3>";

    /* PAYMENT FORM */
    echo "
    <form method='POST'>
        <input type='hidden' name='billing_id' value='$bid'>
        <input type='hidden' name='student_id' value='$sid'>
        <input type='number' step='0.01' name='amount' required>
        <button name='pay'>Pay</button>
    </form>
    ";
}

/* =========================
   SAVE PAYMENT
========================= */
if (isset($_POST['pay'])) {

    $bid = $_POST['billing_id'];
    $sid = $_POST['student_id'];
    $amount = $_POST['amount'];

    $insert = mysqli_query($conn, "
        INSERT INTO payments (
            billing_id,
            student_id,
            amount_paid,
            payment_date
        )
        VALUES (
            '$bid',
            '$sid',
            '$amount',
            NOW()
        )
    ");

    if (!$insert) {
        die("Payment error: " . mysqli_error($conn));
    }

    $id = mysqli_insert_id($conn);

    echo "Payment saved<br>";
    echo "<a href='receipt.php?id=$id'>Print Receipt</a>";
}
?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>