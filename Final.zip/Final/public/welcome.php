<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>University Management System</title>
    <link rel="stylesheet" href="/final/css/style.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            margin: 0;
            font-family: 'Inter', sans-serif;
        }
        
        .welcome-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .welcome-content {
            max-width: 4xl;
            margin: 0 auto;
            text-align: center;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        }
        
        .fade-in {
            animation: fadeIn 0.8s ease-in;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <div class="welcome-container">
        <div class="welcome-content fade-in">
            <!-- University Logo/Branding -->
            <div class="mb-8">
                <div class="text-6xl mb-4">🎓</div>
                <h1 class="text-4xl font-bold text-gray-800 mb-2">University Management System</h1>
                <p class="text-xl text-gray-600">Comprehensive Academic Administration Platform</p>
            </div>

            <!-- Welcome Message -->
            <div class="card mb-8">
                <div class="card-body">
                    <h2 class="text-2xl font-semibold mb-4">Welcome to Our University Portal</h2>
                    <p class="text-gray-600 mb-6">
                        Access your personalized dashboard, manage academic records, process payments, 
                        and stay connected with your educational journey.
                    </p>
                    
                    <!-- Quick Links -->
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                        <a href="../auth/login.php" class="btn btn-primary">
                            🔐 Login
                        </a>
                        <a href="../auth/signup.php" class="btn btn-secondary">
                            📝 Sign Up
                        </a>
                        <a href="../form/eform.php" class="btn btn-outline">
                            📋 Enrollment
                        </a>
                        <a href="../auth/login.php" class="btn btn-outline">
                            ℹ️ Help
                        </a>
                    </div>
                </div>
            </div>

            <!-- Features Section -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div class="card text-center">
                    <div class="text-4xl mb-4">👥</div>
                    <h3 class="font-semibold mb-2">For Students</h3>
                    <p class="text-sm text-gray-600">
                        View grades, manage enrollment, pay fees, and access academic resources
                    </p>
                </div>
                <div class="card text-center">
                    <div class="text-4xl mb-4">👨‍🏫</div>
                    <h3 class="font-semibold mb-2">For Faculty</h3>
                    <p class="text-sm text-gray-600">
                        Manage classes, encode grades, track student progress, and generate reports
                    </p>
                </div>
                <div class="card text-center">
                    <div class="text-4xl mb-4">⚙️</div>
                    <h3 class="font-semibold mb-2">For Admin</h3>
                    <p class="text-sm text-gray-600">
                        Oversee operations, manage users, generate reports, and system administration
                    </p>
                </div>
            </div>

            <!-- System Information -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">📊 System Features</h3>
                </div>
                <div class="card-body">
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-left">
                        <div>
                            <h4 class="font-semibold text-blue-600 mb-2">📚 Academic Management</h4>
                            <ul class="text-sm text-gray-600 space-y-1">
                                <li>• Course enrollment</li>
                                <li>• Grade tracking</li>
                                <li>• Schedule management</li>
                                <li>• Academic records</li>
                            </ul>
                        </div>
                        <div>
                            <h4 class="font-semibold text-green-600 mb-2">💳 Financial Services</h4>
                            <ul class="text-sm text-gray-600 space-y-1">
                                <li>• Online payments</li>
                                <li>• Billing management</li>
                                <li>• Receipt generation</li>
                                <li>• Financial reports</li>
                            </ul>
                        </div>
                        <div>
                            <h4 class="font-semibold text-purple-600 mb-2">👤 User Management</h4>
                            <ul class="text-sm text-gray-600 space-y-1">
                                <li>• Role-based access</li>
                                <li>• Profile management</li>
                                <li>• Permission control</li>
                                <li>• User accounts</li>
                            </ul>
                        </div>
                        <div>
                            <h4 class="font-semibold text-orange-600 mb-2">📈 Reporting</h4>
                            <ul class="text-sm text-gray-600 space-y-1">
                                <li>• Academic reports</li>
                                <li>• Financial summaries</li>
                                <li>• Statistical analysis</li>
                                <li>• Export capabilities</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Footer Information -->
            <div class="mt-8 text-center text-sm text-gray-500">
                <p>© <?= date('Y') ?> University Management System. All rights reserved.</p>
                <p class="mt-2">
                    Need help? Contact the IT Support Team | 
                    <a href="../auth/login.php" class="text-blue-600 hover:underline">Login to Dashboard</a>
                </p>
            </div>
        </div>
    </div>
</div>

</body>
</html>
