<?php
session_start();

// Redirect to welcome page if not logged in
if (!isset($_SESSION['username'])) {
    header('Location: welcome.php');
    exit();
}

// Get user role and redirect to appropriate dashboard
$role = $_SESSION['role'] ?? '';

switch ($role) {
    case 'admin':
        header('Location: ../admin/admin.php');
        break;
    case 'student':
        header('Location: ../student/student_dashboard.php');
        break;
    case 'teacher':
        header('Location: ../teacher/teacher_dashboard.php');
        break;
    case 'cashier':
        header('Location: ../cashier/cashier_dashboard.php');
        break;
    case 'finance':
        header('Location: ../finance/finance_dashboard.php');
        break;
    case 'dean':
        header('Location: ../dean/dean_dashboard.php');
        break;
    case 'records':
        header('Location: ../records/records_dashboard.php');
        break;
    default:
        // If role is not recognized, redirect to welcome
        header('Location: welcome.php');
        break;
}
exit();
?>
