<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit();
}

$user_id = intval($_GET['id']);

// Get user details before updating
$userQuery = mysqli_query($conn, "SELECT username, role FROM users WHERE user_id = $user_id");
$user = mysqli_fetch_assoc($userQuery);

if (!$user) {
    $_SESSION['message'] = 'User not found';
    $_SESSION['message_type'] = 'error';
} else {
    // Update user status
    $result = mysqli_query($conn, "UPDATE users SET status='approved' WHERE user_id = $user_id");
    
    if ($result) {
        $_SESSION['message'] = "User {$user['username']} ({$user['role']}) has been approved successfully.";
        $_SESSION['message_type'] = 'success';
    } else {
        $_SESSION['message'] = 'Error approving user: ' . mysqli_error($conn);
        $_SESSION['message_type'] = 'error';
    }
}

header("Location: admin.php");
exit();
?>