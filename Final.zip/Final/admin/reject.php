<?php
require_once __DIR__ . '/../includes/header.php';

$user_id = intval($_GET['id']);

mysqli_query($conn, "UPDATE users SET status='rejected' WHERE user_id=$user_id");

header("Location: admin.php");
exit();
?>