<?php
require_once __DIR__ . '/../includes/header.php';

// role protection
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit();
}
?>

<h2>Admin Dashboard</h2>

<h3>Pending Users (Login Approval)</h3>

<?php
$resultUsers = mysqli_query($conn, "
    SELECT * FROM users 
    WHERE role IN ('admin','student','dean','teacher','cashier','finance','records')
    AND status='pending'
");

while ($row = mysqli_fetch_assoc($resultUsers)) {
?>
    <div style="margin-bottom:10px;">
        Username: <?php echo $row['username']; ?>
        <br>

        <a href="approve.php?id=<?php echo $row['user_id']; ?>">Approve</a> |
        <a href="reject.php?id=<?php echo $row['user_id']; ?>">Reject</a>
    </div>
<?php
}
?>

<hr>

<h3>System Users</h3>

<?php
$result3 = mysqli_query($conn, "SELECT * FROM users");

while ($row = mysqli_fetch_assoc($result3)) {
    echo "<div>";
    echo "Username: {$row['username']}";
    echo "</div>";
}
?>

<br>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>