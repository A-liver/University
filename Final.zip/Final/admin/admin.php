<?php
require_once __DIR__ . '/../includes/header.php';

// role protection
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit();
}
?>

<div class="fade-in">
    <h1>Admin Dashboard</h1>
    <p class="text-secondary">Manage system users and approvals</p>

    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-<?php echo $_SESSION['message_type']; ?> mb-6">
            <?php 
            echo htmlspecialchars($_SESSION['message']);
            unset($_SESSION['message']);
            unset($_SESSION['message_type']);
            ?>
        </div>
    <?php endif; ?>

    <!-- Statistics Cards -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-value" id="pendingCount">0</div>
            <div class="stat-label">Pending Approvals</div>
        </div>
        <div class="stat-card success">
            <div class="stat-value" id="activeCount">0</div>
            <div class="stat-label">Active Users</div>
        </div>
        <div class="stat-card warning">
            <div class="stat-value" id="totalRoles">7</div>
            <div class="stat-label">User Roles</div>
        </div>
        <div class="stat-card danger">
            <div class="stat-value" id="rejectedCount">0</div>
            <div class="stat-label">Rejected Users</div>
        </div>
    </div>

    <!-- Pending Users Section -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">👥 Pending Users (Login Approval)</h2>
        </div>
        <div class="card-body">
            <?php
            $resultUsers = mysqli_query($conn, "
                SELECT * FROM users 
                WHERE role IN ('admin','student','dean','teacher','cashier','finance','records')
                AND status='pending'
                ORDER BY created_at DESC
            ");

            if (mysqli_num_rows($resultUsers) > 0) {
                while ($row = mysqli_fetch_assoc($resultUsers)) {
            ?>
                    <div class="user-item">
                        <div class="user-info">
                            <div class="user-name"><?php echo htmlspecialchars($row['username']); ?></div>
                            <div class="user-role">
                                Role: <span class="badge badge-primary"><?php echo htmlspecialchars($row['role']); ?></span>
                                <?php if (isset($row['created_at'])): ?>
                                    • Created: <?php echo date('M j, Y', strtotime($row['created_at'])); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="user-actions">
                            <a href="approve.php?id=<?php echo $row['user_id']; ?>" class="btn btn-success btn-sm">
                                ✓ Approve
                            </a>
                            <a href="reject.php?id=<?php echo $row['user_id']; ?>" class="btn btn-danger btn-sm">
                                ✗ Reject
                            </a>
                        </div>
                    </div>
            <?php
                }
            } else {
                echo '<div class="alert alert-info">No pending users at this time.</div>';
            }
            ?>
        </div>
    </div>

    <!-- System Users Section -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">👤 All System Users</h2>
        </div>
        <div class="card-body">
            <?php
            $result3 = mysqli_query($conn, "SELECT * FROM users ORDER BY role, username");
            
            if (mysqli_num_rows($result3) > 0) {
            ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Username</th>
                                <th>Role</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            while ($row = mysqli_fetch_assoc($result3)) {
                                $statusClass = $row['status'] == 'active' ? 'success' : ($row['status'] == 'pending' ? 'warning' : 'danger');
                            ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['username']); ?></td>
                                    <td>
                                        <span class="badge badge-primary">
                                            <?php echo htmlspecialchars($row['role']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?php echo $statusClass; ?>">
                                            <?php echo htmlspecialchars($row['status'] ?? 'unknown'); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($row['status'] == 'pending'): ?>
                                            <a href="approve.php?id=<?php echo $row['user_id']; ?>" class="btn btn-success btn-sm">Approve</a>
                                            <a href="reject.php?id=<?php echo $row['user_id']; ?>" class="btn btn-danger btn-sm">Reject</a>
                                        <?php else: ?>
                                            <span class="text-secondary">No actions</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            <?php
            } else {
                echo '<div class="alert alert-info">No users found in the system.</div>';
            }
            ?>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">⚡ Quick Actions</h2>
        </div>
        <div class="card-body">
            <div class="flex gap-4">
                <a href="../auth/signup.php" class="btn btn-primary">Create New User</a>
                <button onclick="location.reload()" class="btn btn-secondary">Refresh Dashboard</button>
                <a href="../auth/logout.php" class="btn btn-outline">Logout</a>
            </div>
        </div>
    </div>
</div>

<script>
// Update statistics
document.addEventListener('DOMContentLoaded', function() {
    // Count pending users
    const pendingCount = document.querySelectorAll('.user-item').length;
    document.getElementById('pendingCount').textContent = pendingCount;
    
    // Count active users (this would need server-side calculation)
    // For now, showing a placeholder
    document.getElementById('activeCount').textContent = '12';
    document.getElementById('rejectedCount').textContent = '3';
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>