<?php
require_once __DIR__ . '/../includes/header.php';

$cn = $_GET['cn'];
$sy = $_GET['sy'];
$sem = $_GET['sem'];
$sub = $_GET['sub'];

$rows = mysqli_query($conn, "
    SELECT *
    FROM student_subjects
    WHERE cn='$cn'
    AND sy='$sy'
    AND sem='$sem'
    AND subject_code='$sub'
    ORDER BY student_id ASC
");
?>

<h2>Grade Sheet</h2>

<table border="1">
<tr>
    <th>Student ID</th>
    <th>G1</th>
    <th>G2</th>
    <th>G3</th>
    <th>Final</th>
    <th>Remarks</th>
</tr>

<?php while($r = mysqli_fetch_assoc($rows)) { ?>
<tr>
    <td><?= $r['student_id'] ?></td>
    <td><?= $r['g1'] ?></td>
    <td><?= $r['g2'] ?></td>
    <td><?= $r['g3'] ?></td>
    <td><?= $r['final'] ?></td>
    <td><?= $r['remarks'] ?></td>
</tr>
<?php } ?>

</table>

<script>window.print();</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>