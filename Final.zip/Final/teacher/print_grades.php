<?php
require_once __DIR__ . '/../includes/header.php';

$cn = $_GET['cn'];
$sy = $_GET['sy'];
$sem = $_GET['sem'];
$sub = $_GET['sub'];

// Get class information
$classInfo = mysqli_query($conn, "
    SELECT * FROM student_subjects
    WHERE cn='$cn' AND sy='$sy' AND sem='$sem' AND subject_code='$sub'
    LIMIT 1
");
$class = mysqli_fetch_assoc($classInfo);

// Get student grades
$rows = mysqli_query($conn, "
    SELECT ss.*, s.fname, s.lname
    FROM student_subjects ss
    JOIN students s ON s.student_id = ss.student_id
    WHERE ss.cn='$cn'
    AND ss.sy='$sy'
    AND ss.sem='$sem'
    AND ss.subject_code='$sub'
    ORDER BY s.lname ASC, s.fname ASC
");

// Calculate statistics
$statsQuery = mysqli_query($conn, "
    SELECT 
        COUNT(*) as total_students,
        COUNT(CASE WHEN final > 0 THEN 1 END) as graded_students,
        COUNT(CASE WHEN final >= 75 THEN 1 END) as passed_students,
        COUNT(CASE WHEN final < 75 AND final > 0 THEN 1 END) as failed_students,
        AVG(CASE WHEN final > 0 THEN final END) as average_grade
    FROM student_subjects
    WHERE cn='$cn' AND sy='$sy' AND sem='$sem' AND subject_code='$sub'
");
$stats = mysqli_fetch_assoc($statsQuery);
?>

<div class="fade-in">
    <div class="max-w-6xl mx-auto">
        <!-- Grade Sheet Header -->
        <div class="card mb-6">
            <div class="card-body">
                <div class="text-center mb-6">
                    <h1 class="text-3xl font-bold">GRADE SHEET</h1>
                    <p class="text-secondary">Official Academic Record</p>
                </div>
                
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div>
                        <span class="text-secondary text-sm">Class Number</span>
                        <div class="font-semibold"><?= $cn ?></div>
                    </div>
                    <div>
                        <span class="text-secondary text-sm">Subject Code</span>
                        <div class="font-semibold"><?= htmlspecialchars($sub) ?></div>
                    </div>
                    <div>
                        <span class="text-secondary text-sm">School Year</span>
                        <div class="font-semibold"><?= htmlspecialchars($sy) ?></div>
                    </div>
                    <div>
                        <span class="text-secondary text-sm">Semester</span>
                        <div class="font-semibold"><?= htmlspecialchars($sem) ?></div>
                    </div>
                </div>

                <?php if ($class): ?>
                    <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                        <div>
                            <span class="text-secondary text-sm">Subject Description</span>
                            <div class="font-semibold"><?= htmlspecialchars($class['description']) ?></div>
                        </div>
                        <div>
                            <span class="text-secondary text-sm">Instructor</span>
                            <div class="font-semibold"><?= htmlspecialchars($class['instructor']) ?></div>
                        </div>
                        <div>
                            <span class="text-secondary text-sm">Units</span>
                            <div class="font-semibold"><?= $class['units'] ?></div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Grade Statistics -->
        <div class="card mb-6">
            <div class="card-header">
                <h2 class="card-title">📊 Grade Statistics</h2>
            </div>
            <div class="card-body">
                <div class="grid grid-cols-2 md:grid-cols-5 gap-4">
                    <div class="text-center">
                        <div class="text-2xl font-bold"><?= $stats['total_students'] ?? 0 ?></div>
                        <div class="text-sm text-secondary">Total Students</div>
                    </div>
                    <div class="text-center">
                        <div class="text-2xl font-bold text-green-600"><?= $stats['graded_students'] ?? 0 ?></div>
                        <div class="text-sm text-green-500">Graded Students</div>
                    </div>
                    <div class="text-center">
                        <div class="text-2xl font-bold text-blue-600"><?= $stats['passed_students'] ?? 0 ?></div>
                        <div class="text-sm text-blue-500">Passed</div>
                    </div>
                    <div class="text-center">
                        <div class="text-2xl font-bold text-red-600"><?= $stats['failed_students'] ?? 0 ?></div>
                        <div class="text-sm text-red-500">Failed</div>
                    </div>
                    <div class="text-center">
                        <div class="text-2xl font-bold text-purple-600"><?= number_format($stats['average_grade'] ?? 0, 2) ?></div>
                        <div class="text-sm text-purple-500">Average Grade</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Grade Table -->
        <div class="card mb-6">
            <div class="card-header">
                <h2 class="card-title">📋 Student Grades</h2>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Student Name</th>
                                <th>1st Grading</th>
                                <th>2nd Grading</th>
                                <th>3rd Grading</th>
                                <th>Final Grade</th>
                                <th>Remarks</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($r = mysqli_fetch_assoc($rows)) { ?>
                                <tr>
                                    <td><?= $r['student_id'] ?></td>
                                    <td>
                                        <div class="font-semibold"><?= htmlspecialchars($r['lname'] . ', ' . $r['fname']) ?></div>
                                    </td>
                                    <td>
                                        <?php if ($r['g1'] > 0): ?>
                                            <span class="badge badge-<?= $r['g1'] >= 75 ? 'success' : 'danger' ?>">
                                                <?= number_format($r['g1'], 2) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($r['g2'] > 0): ?>
                                            <span class="badge badge-<?= $r['g2'] >= 75 ? 'success' : 'danger' ?>">
                                                <?= number_format($r['g2'], 2) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($r['g3'] > 0): ?>
                                            <span class="badge badge-<?= $r['g3'] >= 75 ? 'success' : 'danger' ?>">
                                                <?= number_format($r['g3'], 2) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($r['final'] > 0): ?>
                                            <span class="badge badge-<?= $r['final'] >= 75 ? 'success' : 'danger' ?>">
                                                <?= number_format($r['final'], 2) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">Not Graded</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($r['remarks']): ?>
                                            <span class="badge badge-<?= $r['remarks'] == 'PASSED' ? 'success' : 'danger' ?>">
                                                <?= htmlspecialchars($r['remarks']) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($r['final'] > 0): ?>
                                            <span class="badge badge-<?= $r['final'] >= 75 ? 'success' : 'danger' ?>">
                                                <?= $r['final'] >= 75 ? '✓ Passed' : '✗ Failed' ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-warning">⏳ In Progress</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Footer Information -->
        <div class="card">
            <div class="card-body">
                <div class="grid grid-cols-3 gap-6 text-center">
                    <div>
                        <div class="border-b-2 border-gray-300 pb-2 mb-2">
                            <strong>Prepared by:</strong>
                        </div>
                        <div class="text-secondary">_________________________</div>
                        <div class="text-sm">Instructor</div>
                    </div>
                    <div>
                        <div class="border-b-2 border-gray-300 pb-2 mb-2">
                            <strong>Verified by:</strong>
                        </div>
                        <div class="text-secondary">_________________________</div>
                        <div class="text-sm">Department Head</div>
                    </div>
                    <div>
                        <div class="border-b-2 border-gray-300 pb-2 mb-2">
                            <strong>Approved by:</strong>
                        </div>
                        <div class="text-secondary">_________________________</div>
                        <div class="text-sm">Dean</div>
                    </div>
                </div>
                
                <div class="mt-6 text-center text-sm text-secondary">
                    <p>Generated on: <?= date('F d, Y h:i A') ?></p>
                    <p>This is an official academic record. Any alterations must be properly documented.</p>
                </div>
            </div>
        </div>

        <!-- Print Button -->
        <div class="text-center mt-6">
            <button onclick="window.print()" class="btn btn-primary">
                🖨️ Print Grade Sheet
            </button>
            <a href="teacher_dashboard.php" class="btn btn-outline ml-2">
                ← Back to Dashboard
            </a>
        </div>
    </div>
</div>

<style>
@media print {
    .text-center button, .text-center a {
        display: none !important;
    }
    
    .card {
        break-inside: avoid;
        page-break-inside: avoid;
        margin-bottom: 20px;
    }
    
    .table-responsive {
        overflow: visible !important;
    }
    
    body {
        background: white !important;
        padding: 20px !important;
    }
    
    .fade-in {
        animation: none !important;
    }
}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>