<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    foreach ($_POST['g1'] as $id => $val) {

        $g1 = $_POST['g1'][$id];
        $g2 = $_POST['g2'][$id];
        $g3 = $_POST['g3'][$id];
        $final = $_POST['final'][$id];
        $remarks = $_POST['remarks'][$id];

        mysqli_query($conn, "
            UPDATE student_subjects SET
                g1='$g1',
                g2='$g2',
                g3='$g3',
                final='$final',
                remarks='$remarks'
            WHERE id='$id'
        ");
    }

    echo "<script>
        alert('Grades saved successfully');
        window.history.back();
    </script>";
}
?>