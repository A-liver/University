<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] != 'teacher') exit("Access denied");

$teacher = $_SESSION['username'];

/* GET DISTINCT SCHEDULES */
$schedules = mysqli_query($conn, "
    SELECT DISTINCT sy, sem, cn, subject_code, description
    FROM student_subjects
    WHERE instructor='$teacher'
    ORDER BY sy DESC, sem DESC
");
?>

<h2>Teacher Dashboard</h2>

<table border="1">
<tr>
    <th>SY</th>
    <th>SEM</th>
    <th>CN</th>
    <th>Subject</th>
    <th>Action</th>
</tr>

<?php while($s = mysqli_fetch_assoc($schedules)) { ?>
<tr>
    <td><?= $s['sy'] ?></td>
    <td><?= $s['sem'] ?></td>
    <td><?= $s['cn'] ?></td>
    <td><?= $s['subject_code'] ?></td>
    <td>
        <a href="class_list.php?cn=<?= $s['cn'] ?>&sy=<?= $s['sy'] ?>&sem=<?= $s['sem'] ?>&sub=<?= $s['subject_code'] ?>">
            Open Class
        </a>
    </td>
</tr>
<?php } ?>

</table>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>