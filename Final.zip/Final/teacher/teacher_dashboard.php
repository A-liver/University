<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] != 'teacher') exit("Access denied");

$teacher = $_SESSION['username'];

/* GET DISTINCT SCHEDULES */
$schedules = mysqli_query($conn, "
    SELECT DISTINCT sy, sem, cn, subject_code, description
    FROM student_subjects
    WHERE instructor='$teacher'
    ORDER BY sy DESC, sem DESC
");

/* GET TEACHER STATS */
$totalClasses = mysqli_num_rows($schedules);
$totalStudents = 0;
if ($totalClasses > 0) {
    $studentCount = mysqli_query($conn, "
        SELECT COUNT(DISTINCT student_id) as total
        FROM student_subjects
        WHERE instructor='$teacher'
    ");
    $totalStudents = mysqli_fetch_assoc($studentCount)['total'];
}
?>

<div class="fade-in">
    <h1>Teacher Dashboard</h1>
    <p class="text-secondary">Manage your classes and student grades</p>

    <!-- Statistics Cards -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-value"><?= $totalClasses ?></div>
            <div class="stat-label">Active Classes</div>
        </div>
        <div class="stat-card success">
            <div class="stat-value"><?= number_format($totalStudents) ?></div>
            <div class="stat-label">Total Students</div>
        </div>
        <div class="stat-card warning">
            <div class="stat-value"><?= $totalClasses > 0 ? round($totalStudents / $totalClasses, 1) : 0 ?></div>
            <div class="stat-label">Avg. Class Size</div>
        </div>
        <div class="stat-card danger">
            <div class="stat-value"><?= date('Y') ?></div>
            <div class="stat-label">Current Year</div>
        </div>
    </div>

    <!-- My Classes -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">📚 My Classes</h2>
        </div>
        <div class="card-body">
            <?php if (mysqli_num_rows($schedules) > 0): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>School Year</th>
                                <th>Semester</th>
                                <th>Class Number</th>
                                <th>Subject Code</th>
                                <th>Description</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($s = mysqli_fetch_assoc($schedules)) { ?>
                                <tr>
                                    <td>
                                        <span class="badge badge-primary"><?= $s['sy'] ?></span>
                                    </td>
                                    <td>
                                        <span class="badge badge-secondary"><?= $s['sem'] ?></span>
                                    </td>
                                    <td><?= htmlspecialchars($s['cn']) ?></td>
                                    <td>
                                        <span class="badge badge-info"><?= htmlspecialchars($s['subject_code']) ?></span>
                                    </td>
                                    <td><?= htmlspecialchars($s['description'] ?? 'N/A') ?></td>
                                    <td>
                                        <div class="flex gap-2">
                                            <a href="class_list.php?cn=<?= $s['cn'] ?>&sy=<?= $s['sy'] ?>&sem=<?= $s['sem'] ?>&sub=<?= $s['subject_code'] ?>" 
                                               class="btn btn-primary btn-sm">
                                                👥 Class List
                                            </a>
                                            <a href="encode_grades.php?cn=<?= $s['cn'] ?>&sy=<?= $s['sy'] ?>&sem=<?= $s['sem'] ?>&sub=<?= $s['subject_code'] ?>" 
                                               class="btn btn-success btn-sm">
                                                📝 Encode Grades
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <strong>No classes assigned yet.</strong> Please contact the dean's office for class assignments.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">⚡ Quick Actions</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-3 gap-4">
                <a href="#" onclick="window.print()" class="btn btn-outline">
                    🖨️ Print Schedule
                </a>
                <a href="#" onclick="location.reload()" class="btn btn-secondary">
                    🔄 Refresh Dashboard
                </a>
                <a href="../auth/logout.php" class="btn btn-danger">
                    🚪 Logout
                </a>
            </div>
        </div>
    </div>

    <!-- Teaching Information -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">ℹ️ Teaching Information</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 gap-6">
                <div>
                    <h4 class="mb-4">Current Semester</h4>
                    <ul class="space-y-2">
                        <li class="flex justify-between">
                            <span>Total Classes:</span>
                            <span class="badge badge-primary"><?= $totalClasses ?></span>
                        </li>
                        <li class="flex justify-between">
                            <span>Total Students:</span>
                            <span class="badge badge-success"><?= number_format($totalStudents) ?></span>
                        </li>
                        <li class="flex justify-between">
                            <span>Average Class Size:</span>
                            <span class="badge badge-warning"><?= $totalClasses > 0 ? round($totalStudents / $totalClasses, 1) : 0 ?></span>
                        </li>
                    </ul>
                </div>
                <div>
                    <h4 class="mb-4">Grade Management</h4>
                    <ul class="space-y-2">
                        <li>• Click "Class List" to view enrolled students</li>
                        <li>• Click "Encode Grades" to input student grades</li>
                        <li>• Print grade sheets for record keeping</li>
                        <li>• Submit grades before deadline</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- Important Notices -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">📋 Important Notices</h2>
        </div>
        <div class="card-body">
            <div class="alert alert-warning">
                <strong>Grade Submission Deadline:</strong> Please ensure all grades are submitted before the end of the semester.
            </div>
            <div class="alert alert-info">
                <strong>Class Attendance:</strong> Regular attendance tracking is required for all assigned classes.
            </div>
            <p class="text-secondary">
                For any issues with class assignments or grade encoding, please contact the dean's office.
            </p>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>