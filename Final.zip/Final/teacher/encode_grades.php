<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] != 'teacher') exit("Access denied");

$cn = $_GET['cn'];
$sy = $_GET['sy'];
$sem = $_GET['sem'];
$sub = $_GET['sub'];

$students = mysqli_query($conn, "
    SELECT *
    FROM student_subjects
    WHERE cn='$cn'
    AND sy='$sy'
    AND sem='$sem'
    AND subject_code='$sub'
    ORDER BY student_id ASC
");
?>

<h2>Encode Grades</h2>

<p>
CN: <?= $cn ?> |
Subject: <?= $sub ?> |
SY: <?= $sy ?> |
SEM: <?= $sem ?>
</p>

<form method="POST" action="save_grades.php">

<table border="1" cellpadding="5">
<tr>
    <th>Student ID</th>
    <th>G1</th>
    <th>G2</th>
    <th>G3</th>
    <th>Final</th>
    <th>Remarks</th>
</tr>

<?php while($s = mysqli_fetch_assoc($students)) { ?>

<tr>
    <td>
        <?= $s['student_id'] ?>
        <input type="hidden" name="id[]" value="<?= $s['id'] ?>">
    </td>

    <td><input type="number" step="0.01" class="g1" name="g1[<?= $s['id'] ?>]" value="<?= $s['g1'] ?>"></td>
    <td><input type="number" step="0.01" class="g2" name="g2[<?= $s['id'] ?>]" value="<?= $s['g2'] ?>"></td>
    <td><input type="number" step="0.01" class="g3" name="g3[<?= $s['id'] ?>]" value="<?= $s['g3'] ?>"></td>

    <td>
        <input type="text" class="final" name="final[<?= $s['id'] ?>]" value="<?= $s['final'] ?>" readonly>
    </td>

    <td>
        <input type="text" class="remarks" name="remarks[<?= $s['id'] ?>]" value="<?= $s['remarks'] ?>" readonly>
    </td>
</tr>

<?php } ?>

</table>

<br>
<button type="submit">Save Grades</button>

</form>

<!-- AUTO CALC SCRIPT -->
<script>
document.querySelectorAll("tr").forEach(row => {

    const g1 = row.querySelector(".g1");
    const g2 = row.querySelector(".g2");
    const g3 = row.querySelector(".g3");
    const final = row.querySelector(".final");
    const remarks = row.querySelector(".remarks");

    function compute() {
        let v1 = parseFloat(g1?.value || 0);
        let v2 = parseFloat(g2?.value || 0);
        let v3 = parseFloat(g3?.value || 0);

        let avg = (v1 + v2 + v3) / 3;

        if (!isNaN(avg)) {
            final.value = avg.toFixed(2);

            if (avg >= 75) {
                remarks.value = "PASSED";
            } else {
                remarks.value = "FAILED";
            }
        }
    }

    if (g1 && g2 && g3) {
        g1.addEventListener("input", compute);
        g2.addEventListener("input", compute);
        g3.addEventListener("input", compute);
    }
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>