<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] != 'dean') exit("Access denied");

/* ENROLL */
if (isset($_POST['enroll'])) {

    mysqli_query($conn, "
        INSERT INTO student_subjects
        (student_id, cn, course, subject_code, description, units, instructor, sem, sy)
        VALUES (
            '{$_POST['student_id']}',
            '{$_POST['cn']}',
            '{$_POST['course']}',
            '{$_POST['code']}',
            '{$_POST['desc']}',
            '{$_POST['units']}',
            '{$_POST['instructor']}',
            '{$_POST['sem']}',
            '{$_POST['sy']}'
        )
    ");
}

/* LIST */
$data = mysqli_query($conn, "
    SELECT ss.*, s.lname, s.fname
    FROM student_subjects ss
    JOIN students s ON s.student_id = ss.student_id
    ORDER BY s.lname ASC
");
?>

<h2>Enrollment</h2>

<table border="1">
<tr>
    <th>Student</th>
    <th>Subject</th>
    <th>SY</th>
    <th>SEM</th>
    <th>Instructor</th>
</tr>

<?php while ($r = mysqli_fetch_assoc($data)) { ?>
<tr>
    <td><?= $r['lname'] ?>, <?= $r['fname'] ?></td>
    <td><?= $r['subject_code'] ?></td>
    <td><?= $r['sy'] ?></td>
    <td><?= $r['sem'] ?></td>
    <td><?= $r['instructor'] ?></td>
</tr>
<?php } ?>

</table>