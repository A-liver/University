<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] != 'dean') exit("Access denied");

$data = mysqli_query($conn, "SELECT * FROM students ORDER BY lname ASC");
?>

<h2>Students</h2>

<table border="1">
<tr><th>Name</th><th>Course</th><th>SY</th><th>SEM</th></tr>

<?php while ($s = mysqli_fetch_assoc($data)) { ?>
<tr>
    <td><?= $s['lname'] ?>, <?= $s['fname'] ?></td>
    <td><?= $s['course'] ?></td>
    <td><?= $s['sy'] ?></td>
    <td><?= $s['sem'] ?></td>
</tr>
<?php } ?>

</table>