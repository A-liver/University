<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] != 'dean') exit("Access denied");

$data = mysqli_query($conn, "SELECT * FROM students ORDER BY lname ASC");

/* GET STATISTICS */
$statsQuery = mysqli_query($conn, "
    SELECT 
        COUNT(*) as total_students,
        COUNT(DISTINCT course) as unique_courses,
        COUNT(DISTINCT sy) as academic_years,
        COUNT(DISTINCT sem) as semesters
    FROM students
");
$stats = mysqli_fetch_assoc($statsQuery);
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1>👥 Student Management</h1>
            <p class="text-secondary">View and manage all registered students</p>
        </div>
        <a href="dean_dashboard.php" class="btn btn-outline">
            ← Back to Dashboard
        </a>
    </div>

    <!-- Statistics Cards -->
    <div class="stats-grid mb-6">
        <div class="stat-card">
            <div class="stat-value"><?= $stats['total_students'] ?? 0 ?></div>
            <div class="stat-label">Total Students</div>
        </div>
        <div class="stat-card success">
            <div class="stat-value"><?= $stats['unique_courses'] ?? 0 ?></div>
            <div class="stat-label">Unique Courses</div>
        </div>
        <div class="stat-card warning">
            <div class="stat-value"><?= $stats['academic_years'] ?? 0 ?></div>
            <div class="stat-label">Academic Years</div>
        </div>
        <div class="stat-card danger">
            <div class="stat-value"><?= $stats['semesters'] ?? 0 ?></div>
            <div class="stat-label">Semesters</div>
        </div>
    </div>

    <!-- Students List -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">📋 All Students</h2>
            <p class="text-sm text-secondary">Complete list of registered students</p>
        </div>
        <div class="card-body">
            <?php if (mysqli_num_rows($data) > 0): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Full Name</th>
                                <th>Course</th>
                                <th>Major</th>
                                <th>School Year</th>
                                <th>Semester</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($s = mysqli_fetch_assoc($data)) { ?>
                                <tr>
                                    <td>
                                        <span class="badge badge-primary"><?= $s['student_id'] ?></span>
                                    </td>
                                    <td>
                                        <div class="font-semibold"><?= htmlspecialchars($s['lname'] . ', ' . $s['fname']) ?></div>
                                        <?php if ($s['mname']): ?>
                                            <div class="text-sm text-secondary"><?= htmlspecialchars($s['mname']) ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge badge-secondary"><?= htmlspecialchars($s['course']) ?></span>
                                    </td>
                                    <td><?= htmlspecialchars($s['major'] ?? 'N/A') ?></td>
                                    <td><?= htmlspecialchars($s['sy']) ?></td>
                                    <td><?= htmlspecialchars($s['sem']) ?></td>
                                    <td>
                                        <div class="flex gap-2">
                                            <button class="btn btn-outline btn-sm">
                                                📊 View Records
                                            </button>
                                            <button class="btn btn-primary btn-sm">
                                                📝 Edit Info
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <strong>No students found.</strong> There are currently no registered students in the system.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="card mt-6">
        <div class="card-header">
            <h2 class="card-title">⚡ Quick Actions</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <a href="enrollment.php" class="btn btn-primary">
                    👥 Student Enrollment
                </a>
                <a href="courses.php" class="btn btn-secondary">
                    📚 Manage Courses
                </a>
                <a href="subjects.php" class="btn btn-outline">
                    📖 Manage Subjects
                </a>
                <a href="dean_dashboard.php" class="btn btn-outline">
                    ← Dashboard
                </a>
            </div>
        </div>
    </div>

    <!-- Important Information -->
    <div class="card mt-6">
        <div class="card-header">
            <h2 class="card-title">📋 Student Management Guidelines</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h4 class="font-semibold mb-3">Student Information:</h4>
                    <ul class="space-y-2 text-sm text-secondary">
                        <li>• All students must have complete profile information</li>
                        <li>• Course and major assignments should be accurate</li>
                        <li>• Academic year and semester tracking is essential</li>
                        <li>• Regular updates to student records recommended</li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold mb-3">Academic Oversight:</h4>
                    <ul class="space-y-2 text-sm text-secondary">
                        <li>• Monitor student enrollment patterns</li>
                        <li>• Track academic progress and performance</li>
                        <li>• Ensure compliance with academic policies</li>
                        <li>• Coordinate with department heads for issues</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>