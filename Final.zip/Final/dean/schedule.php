<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] != 'dean') exit("Access denied");

$data = mysqli_query($conn, "
    SELECT *
    FROM subjectssem120182019
    WHERE INSTRUCTOR IS NOT NULL
");
?>

<h2>Schedule</h2>

<table border="1">
<tr><th>Subject</th><th>Room</th><th>Time</th><th>Instructor</th></tr>

<?php while ($r = mysqli_fetch_assoc($data)) { ?>
<tr>
    <td><?= $r['SUBJECT'] ?></td>
    <td><?= $r['ROOM'] ?></td>
    <td><?= $r['TSTART'] ?> - <?= $r['TEND'] ?></td>
    <td><?= $r['INSTRUCTOR'] ?></td>
</tr>
<?php } ?>

</table>