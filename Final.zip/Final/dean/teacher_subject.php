<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] != 'dean') exit("Access denied");

/* TEACHERS */
$teachers = mysqli_query($conn,"
    SELECT username 
    FROM users 
    WHERE role='teacher'
");

if (!$teachers) {
    die("Teacher query error: " . mysqli_error($conn));
}

/* CLASSES */
$classes = mysqli_query($conn,"
    SELECT DISTINCT cn, subject_code, sy, sem
    FROM student_subjects
    ORDER BY sy DESC
");

if (!$classes) {
    die("Class query error: " . mysqli_error($conn));
}

/* ASSIGN TEACHER */
if (isset($_POST['assign'])) {

    $cn = mysqli_real_escape_string($conn, $_POST['cn']);
    $teacher = mysqli_real_escape_string($conn, $_POST['teacher']);

    $update = mysqli_query($conn,"
        UPDATE student_subjects
        SET instructor='$teacher'
        WHERE cn='$cn'
    ");

    if (!$update) {
        die("Update error: " . mysqli_error($conn));
    }

    echo "<script>alert('Teacher assigned successfully');</script>";
}
?>

<h2>Assign Teacher</h2>

<form method="POST">

    <label>Class (CN / Subject)</label><br>
    <select name="cn" required>
        <?php while($c=mysqli_fetch_assoc($classes)){ ?>
            <option value="<?= $c['cn'] ?>">
                <?= $c['subject_code'].' | SY '.$c['sy'].'-'.$c['sem'] ?>
            </option>
        <?php } ?>
    </select>

    <br><br>

    <label>Teacher</label><br>
    <select name="teacher" required>
        <?php while($t=mysqli_fetch_assoc($teachers)){ ?>
            <option value="<?= $t['username'] ?>">
                <?= $t['username'] ?>
            </option>
        <?php } ?>
    </select>

    <br><br>

    <button name="assign">Assign Teacher</button>
</form>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>