<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] != 'dean') exit("Access denied");

/* ADD */
if (isset($_POST['add'])) {
    mysqli_query($conn, "
        INSERT INTO subjectssem120182019
        (COURSE, SUBJECT, `DESC`, UNIT, ROOM, TERM)
        VALUES (
            '{$_POST['course']}',
            '{$_POST['code']}',
            '{$_POST['desc']}',
            '{$_POST['units']}',
            '{$_POST['room']}',
            '{$_POST['term']}'
        )
    ");
}

/* DELETE */
if (isset($_GET['del'])) {
    mysqli_query($conn, "DELETE FROM subjectssem120182019 WHERE CN='{$_GET['del']}'");
}

$data = mysqli_query($conn, "SELECT * FROM subjectssem120182019");
?>

<h2>Subjects Catalog</h2>

<form method="POST">
    <input name="course" placeholder="Course">
    <input name="code" placeholder="Subject Code">
    <input name="desc" placeholder="Description">
    <input name="units" placeholder="Units">
    <input name="room" placeholder="Room">
    <input name="term" placeholder="Term">
    <button name="add">Add</button>
</form>

<table border="1">
<tr><th>Code</th><th>Desc</th><th>Units</th><th>Action</th></tr>

<?php while ($s = mysqli_fetch_assoc($data)) { ?>
<tr>
    <td><?= $s['SUBJECT'] ?></td>
    <td><?= $s['DESC'] ?></td>
    <td><?= $s['UNIT'] ?></td>
    <td><a href="?del=<?= $s['CN'] ?>">Delete</a></td>
</tr>
<?php } ?>

</table>