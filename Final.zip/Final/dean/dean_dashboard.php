<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] != 'dean') exit("Access denied");

/* STATS */
$students = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS c FROM students"))['c'];
$courses = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS c FROM courses"))['c'];
$enrolled = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS c FROM student_subjects"))['c'];

$activeSY = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT sy, sem, COUNT(*) AS c
    FROM student_subjects
    GROUP BY sy, sem
    ORDER BY sy DESC
    LIMIT 1
"));
?>

<div class="fade-in">
    <h1>Dean Dashboard</h1>
    <p class="text-secondary">Academic administration and oversight</p>

    <!-- Statistics Cards -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-value"><?= number_format($students) ?></div>
            <div class="stat-label">Total Students</div>
        </div>
        <div class="stat-card success">
            <div class="stat-value"><?= number_format($courses) ?></div>
            <div class="stat-label">Active Courses</div>
        </div>
        <div class="stat-card warning">
            <div class="stat-value"><?= number_format($enrolled) ?></div>
            <div class="stat-label">Enrolled Subjects</div>
        </div>
        <div class="stat-card danger">
            <div class="stat-value"><?= $activeSY['sy'] ?? 'N/A' ?> - <?= $activeSY['sem'] ?? 'N/A' ?></div>
            <div class="stat-label">Current SY/SEM</div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">🎓 Academic Management</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 gap-4">
                <a href="courses.php" class="btn btn-primary">
                    📚 Courses Management
                </a>
                <a href="subjects.php" class="btn btn-secondary">
                    📖 Subjects Management
                </a>
                <a href="enrollment.php" class="btn btn-success">
                    ✏️ Enrollment Control
                </a>
                <a href="students.php" class="btn btn-outline">
                    👥 Student Records
                </a>
                <a href="teacher_subject.php" class="btn btn-primary">
                    👨‍🏫 Teacher Assignments
                </a>
                <a href="schedule.php" class="btn btn-secondary">
                    📅 Schedule Management
                </a>
            </div>
        </div>
    </div>

    <!-- Academic Overview -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">📊 Academic Overview</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 gap-6">
                <div>
                    <h4 class="mb-4">Student Statistics</h4>
                    <ul class="space-y-2">
                        <li class="flex justify-between">
                            <span>Total Enrolled:</span>
                            <span class="badge badge-primary"><?= number_format($students) ?></span>
                        </li>
                        <li class="flex justify-between">
                            <span>Active Enrollments:</span>
                            <span class="badge badge-success"><?= number_format($enrolled) ?></span>
                        </li>
                        <li class="flex justify-between">
                            <span>Avg. Subjects/Student:</span>
                            <span class="badge badge-warning"><?= $students > 0 ? round($enrolled / $students, 1) : 0 ?></span>
                        </li>
                    </ul>
                </div>
                <div>
                    <h4 class="mb-4">Curriculum Information</h4>
                    <ul class="space-y-2">
                        <li class="flex justify-between">
                            <span>Total Courses:</span>
                            <span class="badge badge-primary"><?= number_format($courses) ?></span>
                        </li>
                        <li class="flex justify-between">
                            <span>Current School Year:</span>
                            <span class="badge badge-info"><?= $activeSY['sy'] ?? 'Not Set' ?></span>
                        </li>
                        <li class="flex justify-between">
                            <span>Current Semester:</span>
                            <span class="badge badge-info"><?= $activeSY['sem'] ?? 'Not Set' ?></span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Activity -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">🔔 Recent Activity</h2>
        </div>
        <div class="card-body">
            <div class="alert alert-info">
                <strong>System Status:</strong> Academic year <?= $activeSY['sy'] ?? 'Not Set' ?>, Semester <?= $activeSY['sem'] ?? 'Not Set' ?> is currently active.
            </div>
            <p class="text-secondary">
                Monitor enrollment progress, course availability, and teacher assignments through the management tools above.
            </p>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>