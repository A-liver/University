<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] != 'dean') exit("Access denied");

/* STATS */
$students = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS c FROM students"))['c'];
$courses = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS c FROM courses"))['c'];
$enrolled = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS c FROM student_subjects"))['c'];

$activeSY = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT sy, sem, COUNT(*) AS c
    FROM student_subjects
    GROUP BY sy, sem
    ORDER BY sy DESC
    LIMIT 1
"));
?>

<h1>Dean Dashboard</h1>

<div>
    <p>Students: <?= $students ?></p>
    <p>Courses: <?= $courses ?></p>
    <p>Enrolled Subjects: <?= $enrolled ?></p>
    <p>Active SY/SEM: <?= $activeSY['sy'] ?? '-' ?> - <?= $activeSY['sem'] ?? '-' ?></p>
</div>

<hr>

<ul>
    <li><a href="courses.php">Courses</a></li>
    <li><a href="subjects.php">Subjects</a></li>
    <li><a href="enrollment.php">Enrollment</a></li>
    <li><a href="students.php">Students</a></li>
    <li><a href="teacher_subject.php">Teachers</a></li>
    <li><a href="schedule.php">Schedule</a></li>
</ul>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>