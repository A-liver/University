<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] != 'dean') exit("Access denied");

/* ADD */
if (isset($_POST['add'])) {
    mysqli_query($conn, "
        INSERT INTO courses (COURSE, `DESC`, MAJOR)
        VALUES (
            '{$_POST['course']}',
            '{$_POST['desc']}',
            '{$_POST['major']}'
        )
    ");
}

/* DELETE */
if (isset($_GET['del'])) {
    mysqli_query($conn, "DELETE FROM courses WHERE id=" . intval($_GET['del']));
}

$data = mysqli_query($conn, "SELECT * FROM courses");
?>

<h2>Courses</h2>

<form method="POST">
    <input name="course" placeholder="Course Code" required>
    <input name="desc" placeholder="Description" required>
    <input name="major" placeholder="Major">
    <button name="add">Add</button>
</form>

<table border="1">
<tr><th>Course</th><th>Desc</th><th>Action</th></tr>

<?php while ($c = mysqli_fetch_assoc($data)) { ?>
<tr>
    <td><?= $c['COURSE'] ?></td>
    <td><?= $c['DESC'] ?></td>
    <td><a href="?del=<?= $c['id'] ?>">Delete</a></td>
</tr>
<?php } ?>

</table>