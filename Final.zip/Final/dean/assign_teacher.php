<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] != 'dean') exit("Access denied");

$teachers = mysqli_query($conn,"SELECT username FROM users WHERE role='teacher'");

$classes = mysqli_query($conn,"
    SELECT DISTINCT cn, subject_code, sy, sem
    FROM student_subjects
    ORDER BY sy DESC
");

if (isset($_POST['assign'])) {

    $cn = $_POST['cn'];
    $teacher = $_POST['teacher'];

    mysqli_query($conn,"
        UPDATE student_subjects
        SET instructor='$teacher'
        WHERE cn='$cn'
    ");

    echo "<script>alert('Teacher assigned');</script>";
}
?>

<h2>Assign Teacher</h2>

<form method="POST">

    <select name="cn">
        <?php while($c=mysqli_fetch_assoc($classes)){ ?>
            <option value="<?= $c['cn'] ?>">
                <?= $c['subject_code'].' | '.$c['sy'].'-'.$c['sem'] ?>
            </option>
        <?php } ?>
    </select>

    <select name="teacher">
        <?php while($t=mysqli_fetch_assoc($teachers)){ ?>
            <option value="<?= $t['username'] ?>">
                <?= $t['username'] ?>
            </option>
        <?php } ?>
    </select>

    <button name="assign">Assign</button>
</form> 