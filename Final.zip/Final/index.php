<?php
session_start();

// Redirect to public folder
header('Location: public/');
exit();
?>
