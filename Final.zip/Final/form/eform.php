<?php
require_once __DIR__ . '/../includes/init.php';

/* LOAD COURSES FROM DB */
$courses = [];

$query = mysqli_query($conn, "SELECT DISTINCT COURSE, MAJOR FROM COURSES");

while ($row = mysqli_fetch_assoc($query)) {
    $courses[] = $row;
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Student Enrollment Form</title>
</head>

<body>

<form method="POST" action="saved.php" enctype="multipart/form-data">

  <h2>Student Enrollment Form</h2>

  <!-- School Year & Semester -->
  <div class="row">
    <div>
      <label>School Year</label>
      <select name="sy" required>
        <option value="">Select School Year</option>
        <option value="2023-2024">2023-2024</option>
        <option value="2024-2025">2024-2025</option>
        <option value="2025-2026">2025-2026</option>
      </select>
    </div>

    <div>
      <label>Semester</label>
      <select name="sem" required>
        <option value="">Select</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
      </select>
    </div>
  </div>

  <!-- Course & Major -->
  <div class="row">

    <div>
      <label>Course</label>
      <select name="course" id="course" required>
        <option value="">Select Course</option>

        <?php
        $seen = [];
        foreach ($courses as $row) {
            if (!in_array($row['COURSE'], $seen)) {
                $seen[] = $row['COURSE'];
                echo "<option value='{$row['COURSE']}'>{$row['COURSE']}</option>";
            }
        }
        ?>

      </select>
    </div>

    <div>
      <label>Major</label>
      <select name="major" id="major">
        <option value="">Select Major</option>
      </select>
    </div>

  </div>

  <div class="row">
    <div>
      <label>First Name</label>
      <input type="text" name="fname" required>
    </div>

    <div>
      <label>Middle Name</label>
      <input type="text" name="mname">
    </div>

    <div>
      <label>Last Name</label>
      <input type="text" name="lname" required>
    </div>
  </div>

  <!-- Birthdate / Age / Gender -->
  <div class="row">
    <div>
      <label>Birth Date</label>
      <input type="date" id="bdate" name="bdate" required>
    </div>

    <div>
      <label>Age</label>
      <input type="number" id="age" name="age" readonly>
    </div>

    <div>
      <label>Gender</label>
      <select name="gender" required>
        <option value="">Select</option>
        <option value="male">Male</option>
        <option value="female">Female</option>
        <option value="other">Other</option>
      </select>
    </div>
  </div>

  <!-- Contact -->
  <div class="row">
    <div>
      <label>Phone</label>
      <input type="text" name="phone" required>
    </div>

    <div>
      <label>Email</label>
      <input type="email" name="email" required>
    </div>
  </div>

  <!-- Religion / Ethnicity -->
  <div class="row">
    <div>
      <label>Religion</label>
      <select name="religion" id="religion" required>
        <option value="">Select Religion</option>
      </select>
    </div>
  </div>

  <div class="row">
    <div>
      <label>Ethnicity</label>
      <select name="ethnicity" id="ethnicity" required>
        <option value="">Select Ethnicity</option>
      </select>
    </div>
  </div>

  <!-- Address -->
  <div class="section">

    <h3>Address</h3>

    <div class="row">
      <div>
        <label>Country</label>
        <input type="text" name="country" value="Philippines" readonly>
      </div>

      <div>
        <label>Region</label>
        <select name="region" id="region" required>
          <option value="">Loading regions...</option>
        </select>
      </div>
    </div>

    <div class="row">
      <div>
        <label>City</label>
        <select name="city" id="city" required>
          <option value="">Select City</option>
        </select>
      </div>

      <div>
        <label>Barangay</label>
        <select name="barangay" id="barangay" required>
          <option value="">Select Barangay</option>
        </select>
      </div>
    </div>

  </div>

  <!-- Image -->
  <div class="section">
    <h3>Upload Image</h3>

    <div id="dropbox">
      <p>Drag & Drop or Click</p>
      <input type="file" id="imageInput" name="imageInput" accept="image/*" required>
      <img id="preview" style="display:none;">
    </div>
  </div>

  <!-- Guardian -->
  <div class="section">
    <h3>Guardian Info</h3>

    <div class="row">
      <div>
        <label>Name</label>
        <input type="text" name="guardian_name" required>
      </div>

      <div>
        <label>Contact</label>
        <input type="text" name="guardian_contact" required>
      </div>
    </div>

    <div class="row">
      <div>
        <label>Address</label>
        <input type="text" name="guardian_address" required>
      </div>
    </div>

  </div>

  <button type="submit">Save</button>

</form>

<script>

/* AGE */
const birthdateInput = document.getElementById("bdate");
const ageInput = document.getElementById("age");

birthdateInput.max = new Date().toISOString().split("T")[0];

birthdateInput.addEventListener("change", function () {
  const birthDate = new Date(this.value);
  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  ageInput.value = age;
});

/* COURSE → FIXED */
const coursesData = <?php echo json_encode($courses); ?>;

const courseSelect = document.getElementById("course");
const majorSelect = document.getElementById("major");

courseSelect.addEventListener("change", function () {
  const selectedCourse = this.value;

  majorSelect.innerHTML = '<option value="">Select Major</option>';

  coursesData.forEach(item => {
    if (item.COURSE === selectedCourse && item.MAJOR) {
      let opt = document.createElement("option");
      opt.value = item.MAJOR;
      opt.textContent = item.MAJOR;
      majorSelect.appendChild(opt);
    }
  });
});

/* REGION */
fetch("../api/fetch_region.php")
.then(r => r.json())
.then(data => {
  const region = document.getElementById("region");
  region.innerHTML = '<option value="">Select Region</option>';

  data.forEach(i => {
    let opt = document.createElement("option");
    opt.value = i.REGION;
    opt.textContent = i.REGION;
    region.appendChild(opt);
  });
});

/* CITY */
document.getElementById("region").addEventListener("change", function () {

  fetch("../api/fetch_cities.php?r=" + encodeURIComponent(this.value))
  .then(r => r.json())
  .then(data => {
    const city = document.getElementById("city");
    city.innerHTML = '<option value="">Select City</option>';

    data.forEach(i => {
      let opt = document.createElement("option");
      opt.value = i.CITIES_MUNICIPALITIES;
      opt.textContent = i.CITIES_MUNICIPALITIES;
      city.appendChild(opt);
    });
  });

});

/* BARANGAY (UNCHANGED) */
const barangaySelect = document.getElementById("barangay");

const barangays = {
  "General Santos City": ["Apopong","Baluan","Batomelong","Buayan","Bula","Calumpang","City Heights","Conel",
           "Dadiangas East","Dadiangas North","Dadiangas South","Dadiangas West","Fatima","Katangawan",
           "Labangal","Lagao","Ligaya","Olympog","San Isidro","San Jose","Siguel","Sinawal","Tambler","Tinagacan"],

  "Alabel": ["Alegria","Bagacay","Baluntay","Domolok","Kawas","Maribulan","Pag-asa","Poblacion"],

  "Glan": ["Batulaki","Big Margus","Burias","Cablalan","Calabanit","Cross","Gumasa","Poblacion"],

  "Kiamba": ["Badtasan","Datu Dani","Katubao","Kayupo","Lagundi","Lomuyon","Poblacion"],

  "Maasim": ["Amsipit","Colon","Daliao","Kabatiol","Kamanga","Kanalo","Poblacion"],

  "Malapatan": ["Daan Suyan","Kinam","Libi","Lun Padidu","Poblacion","Sapu Masla","Tuyan"],

  "Malungon": ["Ampon","Banate","Datal Batong","Datal Bila","Kibala","Kinapulan","Poblacion"]
};

document.getElementById("city").addEventListener("change", function () {
  let selectedCity = this.value.trim().toLowerCase();

  barangaySelect.innerHTML = '<option value="">Select Barangay</option>';

  for (let key in barangays) {
    if (key.toLowerCase() === selectedCity) {
      barangays[key].forEach(brgy => {
        let opt = document.createElement("option");
        opt.value = brgy;
        opt.textContent = brgy;
        barangaySelect.appendChild(opt);
      });
    }
  }
});

/* RELIGION */
fetch("../api/fetch_religion.php")
.then(r => r.json())
.then(data => {
  const rel = document.getElementById("religion");
  rel.innerHTML = '<option value="">Select Religion</option>';

  data.forEach(i => {
    let opt = document.createElement("option");
    opt.value = i.religion;
    opt.textContent = i.religion;
    rel.appendChild(opt);
  });
});

/* ETHNICITY */
fetch("../api/fetch_ethnicity.php")
.then(r => r.json())
.then(data => {
  const eth = document.getElementById("ethnicity");
  eth.innerHTML = '<option value="">Select Ethnicity</option>';

  data.forEach(i => {
    let opt = document.createElement("option");
    opt.value = i.ethnicname;
    opt.textContent = i.ethnicname;
    eth.appendChild(opt);
  });
});

/* IMAGE */
const dropbox = document.getElementById("dropbox");
const imageInput = document.getElementById("imageInput");
const preview = document.getElementById("preview");

dropbox.addEventListener("click", ()=> imageInput.click());

imageInput.addEventListener("change", (e)=>{
  const file = e.target.files[0];
  if(file && file.type.startsWith("image/")){
    const reader = new FileReader();
    reader.onload = e => {
      preview.src = e.target.result;
      preview.style.display = "block";
    };
    reader.readAsDataURL(file);
  }
});

</script>

</body>
</html>