<?php
require_once __DIR__ . '/../includes/init.php';

/* LOAD COURSES FROM DB */
$courses = [];

$query = mysqli_query($conn, "SELECT DISTINCT COURSE, MAJOR FROM COURSES");

while ($row = mysqli_fetch_assoc($query)) {
    $courses[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Enrollment Form</title>
    <link rel="stylesheet" href="/final/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        .enrollment-container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 2rem;
            background: var(--bg-secondary);
            min-height: 100vh;
        }
        
        .enrollment-header {
            text-align: center;
            margin-bottom: 3rem;
        }
        
        .enrollment-header h1 {
            color: var(--primary-color);
            font-size: 2.5rem;
            margin-bottom: 1rem;
        }
        
        .form-section {
            background: var(--bg-primary);
            border-radius: var(--radius-lg);
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-md);
        }
        
        .form-section h3 {
            color: var(--primary-color);
            border-bottom: 2px solid var(--border-color);
            padding-bottom: 0.5rem;
            margin-bottom: 1.5rem;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 1.5rem;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
        }
        
        .form-group label {
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 0.5rem;
        }
        
        .form-group input,
        .form-group select {
            padding: 0.75rem;
            border: 2px solid var(--border-color);
            border-radius: var(--radius-md);
            font-size: 1rem;
            transition: border-color 0.2s ease;
        }
        
        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: var(--primary-light);
        }
        
        .dropbox {
            border: 2px dashed var(--border-color);
            border-radius: var(--radius-md);
            padding: 2rem;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s ease;
            background: var(--bg-secondary);
        }
        
        .dropbox:hover {
            border-color: var(--primary-light);
            background: var(--bg-primary);
        }
        
        .dropbox p {
            color: var(--text-secondary);
            margin-bottom: 1rem;
        }
        
        #preview {
            max-width: 200px;
            max-height: 200px;
            border-radius: var(--radius-md);
            margin: 0 auto;
        }
        
        .submit-section {
            text-align: center;
            margin-top: 3rem;
        }
        
        .submit-btn {
            background: var(--primary-color);
            color: white;
            padding: 1rem 3rem;
            border: none;
            border-radius: var(--radius-md);
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .submit-btn:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }
        
        .required {
            color: var(--accent-color);
        }
        
        @media (max-width: 768px) {
            .enrollment-container {
                padding: 1rem;
            }
            
            .form-section {
                padding: 1.5rem;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .enrollment-header h1 {
                font-size: 2rem;
            }
        }
    </style>
</head>

<body>
    <div class="enrollment-container">
        <div class="enrollment-header fade-in">
            <h1>🎓 Student Enrollment Form</h1>
            <p class="text-secondary">Complete the form below to enroll as a new student</p>
        </div>

        <form method="POST" action="saved.php" enctype="multipart/form-data" id="enrollmentForm">
            
            <!-- Academic Information -->
            <div class="form-section fade-in">
                <h3>📚 Academic Information</h3>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="sy">School Year <span class="required">*</span></label>
                        <select name="sy" id="sy" required>
                            <option value="">Select School Year</option>
                            <option value="2023-2024">2023-2024</option>
                            <option value="2024-2025">2024-2025</option>
                            <option value="2025-2026">2025-2026</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="sem">Semester <span class="required">*</span></label>
                        <select name="sem" id="sem" required>
                            <option value="">Select Semester</option>
                            <option value="1">1st Semester</option>
                            <option value="2">2nd Semester</option>
                            <option value="3">Summer</option>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="course">Course <span class="required">*</span></label>
                        <select name="course" id="course" required>
                            <option value="">Select Course</option>
                            <?php
                            $seen = [];
                            foreach ($courses as $row) {
                                if (!in_array($row['COURSE'], $seen)) {
                                    $seen[] = $row['COURSE'];
                                    echo "<option value='{$row['COURSE']}'>{$row['COURSE']}</option>";
                                }
                            }
                            ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="major">Major</label>
                        <select name="major" id="major">
                            <option value="">Select Major</option>
                        </select>
                    </div>
                </div>
            </div>

  <!-- Personal Information -->
            <div class="form-section fade-in">
                <h3>👤 Personal Information</h3>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="fname">First Name <span class="required">*</span></label>
                        <input type="text" name="fname" id="fname" required placeholder="Enter your first name">
                    </div>

                    <div class="form-group">
                        <label for="mname">Middle Name</label>
                        <input type="text" name="mname" id="mname" placeholder="Enter your middle name">
                    </div>

                    <div class="form-group">
                        <label for="lname">Last Name <span class="required">*</span></label>
                        <input type="text" name="lname" id="lname" required placeholder="Enter your last name">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="bdate">Birth Date <span class="required">*</span></label>
                        <input type="date" id="bdate" name="bdate" required>
                    </div>

                    <div class="form-group">
                        <label for="age">Age</label>
                        <input type="number" id="age" name="age" readonly placeholder="Auto-calculated">
                    </div>

                    <div class="form-group">
                        <label for="gender">Gender <span class="required">*</span></label>
                        <select name="gender" id="gender" required>
                            <option value="">Select Gender</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Contact Information -->
            <div class="form-section fade-in">
                <h3>📞 Contact Information</h3>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="phone">Phone Number <span class="required">*</span></label>
                        <input type="text" name="phone" id="phone" required placeholder="Enter your phone number">
                    </div>

                    <div class="form-group">
                        <label for="email">Email Address <span class="required">*</span></label>
                        <input type="email" name="email" id="email" required placeholder="Enter your email address">
                    </div>
                </div>
            </div>

            <!-- Demographic Information -->
            <div class="form-section fade-in">
                <h3>🌍 Demographic Information</h3>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="religion">Religion <span class="required">*</span></label>
                        <select name="religion" id="religion" required>
                            <option value="">Select Religion</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="ethnicity">Ethnicity <span class="required">*</span></label>
                        <select name="ethnicity" id="ethnicity" required>
                            <option value="">Select Ethnicity</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Address Information -->
            <div class="form-section fade-in">
                <h3>🏠 Address Information</h3>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="country">Country</label>
                        <input type="text" name="country" id="country" value="Philippines" readonly>
                    </div>

                    <div class="form-group">
                        <label for="region">Region <span class="required">*</span></label>
                        <select name="region" id="region" required>
                            <option value="">Loading regions...</option>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="city">City/Municipality <span class="required">*</span></label>
                        <select name="city" id="city" required>
                            <option value="">Select City</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="barangay">Barangay <span class="required">*</span></label>
                        <select name="barangay" id="barangay" required>
                            <option value="">Select Barangay</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Photo Upload -->
            <div class="form-section fade-in">
                <h3>📸 Student Photo</h3>
                
                <div id="dropbox">
                    <p>📤 Drag & Drop your photo here or click to browse</p>
                    <input type="file" id="imageInput" name="imageInput" accept="image/*" required>
                    <img id="preview" style="display:none;" alt="Photo preview">
                </div>
                <p class="text-secondary text-sm mt-2">Please upload a recent passport-sized photo (JPG/PNG format)</p>
            </div>

            <!-- Guardian Information -->
            <div class="form-section fade-in">
                <h3>👨‍👩‍👧‍👦 Guardian Information</h3>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="guardian_name">Guardian Name <span class="required">*</span></label>
                        <input type="text" name="guardian_name" id="guardian_name" required placeholder="Enter guardian's full name">
                    </div>

                    <div class="form-group">
                        <label for="guardian_contact">Guardian Contact <span class="required">*</span></label>
                        <input type="text" name="guardian_contact" id="guardian_contact" required placeholder="Enter guardian's contact number">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="guardian_address">Guardian Address <span class="required">*</span></label>
                        <input type="text" name="guardian_address" id="guardian_address" required placeholder="Enter guardian's complete address">
                    </div>
                </div>
            </div>

            <!-- Submit Section -->
            <div class="submit-section fade-in">
                <div class="alert alert-info mb-4">
                    <strong>Important:</strong> Please review all information before submitting. Make sure all required fields are filled correctly.
                </div>
                <button type="submit" class="submit-btn" id="submitBtn">
                    🎓 Submit Enrollment Application
                </button>
                <p class="text-secondary mt-4">
                    By submitting this form, you confirm that all information provided is accurate and complete.
                </p>
            </div>
        </form>
    </div>

<script>
// Enhanced form validation and interactions
document.addEventListener('DOMContentLoaded', function() {
    
    /* AGE CALCULATION */
    const birthdateInput = document.getElementById("bdate");
    const ageInput = document.getElementById("age");

    birthdateInput.max = new Date().toISOString().split("T")[0];

    birthdateInput.addEventListener("change", function () {
        const birthDate = new Date(this.value);
        const today = new Date();
        let age = today.getFullYear() - birthDate.getFullYear();
        const monthDiff = today.getMonth() - birthDate.getMonth();
        if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
            age--;
        }
        ageInput.value = age;
    });

    /* COURSE → MAJOR SELECTION */
    const coursesData = <?php echo json_encode($courses); ?>;
    const courseSelect = document.getElementById("course");
    const majorSelect = document.getElementById("major");

    courseSelect.addEventListener("change", function () {
        const selectedCourse = this.value;
        majorSelect.innerHTML = '<option value="">Select Major</option>';

        coursesData.forEach(item => {
            if (item.COURSE === selectedCourse && item.MAJOR) {
                let opt = document.createElement("option");
                opt.value = item.MAJOR;
                opt.textContent = item.MAJOR;
                majorSelect.appendChild(opt);
            }
        });
    });

    /* REGION LOADING */
    fetch("../api/fetch_region.php")
    .then(r => r.json())
    .then(data => {
        const region = document.getElementById("region");
        region.innerHTML = '<option value="">Select Region</option>';

        data.forEach(i => {
            let opt = document.createElement("option");
            opt.value = i.REGION;
            opt.textContent = i.REGION;
            region.appendChild(opt);
        });
    })
    .catch(error => {
        console.error('Error loading regions:', error);
        document.getElementById("region").innerHTML = '<option value="">Error loading regions</option>';
    });

    /* CITY LOADING */
    document.getElementById("region").addEventListener("change", function () {
        const citySelect = document.getElementById("city");
        citySelect.innerHTML = '<option value="">Loading cities...</option>';
        
        if (this.value) {
            fetch("../api/fetch_cities.php?r=" + encodeURIComponent(this.value))
            .then(r => r.json())
            .then(data => {
                citySelect.innerHTML = '<option value="">Select City</option>';
                data.forEach(i => {
                    let opt = document.createElement("option");
                    opt.value = i.CITIES_MUNICIPALITIES;
                    opt.textContent = i.CITIES_MUNICIPALITIES;
                    citySelect.appendChild(opt);
                });
            })
            .catch(error => {
                console.error('Error loading cities:', error);
                citySelect.innerHTML = '<option value="">Error loading cities</option>';
            });
        } else {
            citySelect.innerHTML = '<option value="">Select Region first</option>';
        }
    });

    /* BARANGAY LOADING */
    const barangaySelect = document.getElementById("barangay");
    const barangays = {
        "General Santos City": ["Apopong","Baluan","Batomelong","Buayan","Bula","Calumpang","City Heights","Conel",
               "Dadiangas East","Dadiangas North","Dadiangas South","Dadiangas West","Fatima","Katangawan",
               "Labangal","Lagao","Ligaya","Olympog","San Isidro","San Jose","Siguel","Sinawal","Tambler","Tinagacan"],
        "Alabel": ["Alegria","Bagacay","Baluntay","Domolok","Kawas","Maribulan","Pag-asa","Poblacion"],
        "Glan": ["Batulaki","Big Margus","Burias","Cablalan","Calabanit","Cross","Gumasa","Poblacion"],
        "Kiamba": ["Badtasan","Datu Dani","Katubao","Kayupo","Lagundi","Lomuyon","Poblacion"],
        "Maasim": ["Amsipit","Colon","Daliao","Kabatiol","Kamanga","Kanalo","Poblacion"],
        "Malapatan": ["Daan Suyan","Kinam","Libi","Lun Padidu","Poblacion","Sapu Masla","Tuyan"],
        "Malungon": ["Ampon","Banate","Datal Batong","Datal Bila","Kibala","Kinapulan","Poblacion"]
    };

    document.getElementById("city").addEventListener("change", function () {
        let selectedCity = this.value.trim();
        barangaySelect.innerHTML = '<option value="">Select Barangay</option>';

        if (barangays[selectedCity]) {
            barangays[selectedCity].forEach(brgy => {
                let opt = document.createElement("option");
                opt.value = brgy;
                opt.textContent = brgy;
                barangaySelect.appendChild(opt);
            });
        }
    });

    /* RELIGION LOADING */
    fetch("../api/fetch_religion.php")
    .then(r => r.json())
    .then(data => {
        const rel = document.getElementById("religion");
        rel.innerHTML = '<option value="">Select Religion</option>';
        data.forEach(i => {
            let opt = document.createElement("option");
            opt.value = i.religion;
            opt.textContent = i.religion;
            rel.appendChild(opt);
        });
    })
    .catch(error => {
        console.error('Error loading religions:', error);
        document.getElementById("religion").innerHTML = '<option value="">Error loading religions</option>';
    });

    /* ETHNICITY LOADING */
    fetch("../api/fetch_ethnicity.php")
    .then(r => r.json())
    .then(data => {
        const eth = document.getElementById("ethnicity");
        eth.innerHTML = '<option value="">Select Ethnicity</option>';
        data.forEach(i => {
            let opt = document.createElement("option");
            opt.value = i.ethnicname;
            opt.textContent = i.ethnicname;
            eth.appendChild(opt);
        });
    })
    .catch(error => {
        console.error('Error loading ethnicities:', error);
        document.getElementById("ethnicity").innerHTML = '<option value="">Error loading ethnicities</option>';
    });

    /* IMAGE UPLOAD */
    const dropbox = document.getElementById("dropbox");
    const imageInput = document.getElementById("imageInput");
    const preview = document.getElementById("preview");

    dropbox.addEventListener("click", () => imageInput.click());
    
    dropbox.addEventListener("dragover", (e) => {
        e.preventDefault();
        dropbox.style.borderColor = "var(--primary-light)";
        dropbox.style.background = "var(--bg-primary)";
    });
    
    dropbox.addEventListener("dragleave", (e) => {
        e.preventDefault();
        dropbox.style.borderColor = "var(--border-color)";
        dropbox.style.background = "var(--bg-secondary)";
    });
    
    dropbox.addEventListener("drop", (e) => {
        e.preventDefault();
        dropbox.style.borderColor = "var(--border-color)";
        dropbox.style.background = "var(--bg-secondary)";
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            handleImageUpload(files[0]);
        }
    });

    imageInput.addEventListener("change", (e) => {
        const file = e.target.files[0];
        if (file) {
            handleImageUpload(file);
        }
    });

    function handleImageUpload(file) {
        if (file.type.startsWith("image/")) {
            if (file.size > 5 * 1024 * 1024) { // 5MB limit
                alert('Image size should be less than 5MB');
                return;
            }
            
            const reader = new FileReader();
            reader.onload = e => {
                preview.src = e.target.result;
                preview.style.display = "block";
                dropbox.querySelector('p').textContent = '✅ Photo uploaded successfully';
                dropbox.querySelector('p').style.color = 'var(--success-color)';
            };
            reader.readAsDataURL(file);
        } else {
            alert('Please upload an image file (JPG, PNG, etc.)');
        }
    }

    /* FORM VALIDATION */
    const form = document.getElementById('enrollmentForm');
    const submitBtn = document.getElementById('submitBtn');
    
    form.addEventListener('submit', function(e) {
        // Basic validation
        const requiredFields = form.querySelectorAll('[required]');
        let isValid = true;
        
        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                field.style.borderColor = 'var(--accent-color)';
                isValid = false;
            } else {
                field.style.borderColor = 'var(--border-color)';
            }
        });
        
        if (!isValid) {
            e.preventDefault();
            alert('Please fill in all required fields marked with *');
            return;
        }
        
        // Email validation
        const email = document.getElementById('email').value;
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            e.preventDefault();
            alert('Please enter a valid email address');
            return;
        }
        
        // Phone validation (basic)
        const phone = document.getElementById('phone').value;
        if (phone.length < 10) {
            e.preventDefault();
            alert('Please enter a valid phone number');
            return;
        }
        
        // Show loading state
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner" style="width: 20px; height: 20px; margin-right: 8px;"></span> Submitting...';
    });

    /* Add input animations */
    const inputs = document.querySelectorAll('input, select');
    inputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.classList.add('focused');
        });
        
        input.addEventListener('blur', function() {
            if (!this.value) {
                this.parentElement.classList.remove('focused');
            }
        });
    });
});

// Add CSS animations for form sections
const style = document.createElement('style');
style.textContent = `
    .form-group {
        position: relative;
        transition: all 0.3s ease;
    }
    
    .form-group.focused label {
        color: var(--primary-light);
        transform: translateY(-2px);
    }
    
    .form-group input:focus,
    .form-group select:focus {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(59, 130, 246, 0.15);
    }
    
    .form-section {
        opacity: 0;
        transform: translateY(20px);
        animation: fadeInUp 0.6s ease forwards;
    }
    
    .form-section:nth-child(1) { animation-delay: 0.1s; }
    .form-section:nth-child(2) { animation-delay: 0.2s; }
    .form-section:nth-child(3) { animation-delay: 0.3s; }
    .form-section:nth-child(4) { animation-delay: 0.4s; }
    .form-section:nth-child(5) { animation-delay: 0.5s; }
    .form-section:nth-child(6) { animation-delay: 0.6s; }
    .form-section:nth-child(7) { animation-delay: 0.7s; }
    
    @keyframes fadeInUp {
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
`;
document.head.appendChild(style);
</script>

</body>
</html>