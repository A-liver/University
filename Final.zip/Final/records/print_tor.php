<?php
require_once __DIR__ . '/../includes/header.php';

$id = mysqli_real_escape_string($conn, $_GET['id']);

$student = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT * FROM students WHERE student_id='$id'
"));

if (!$student) {
    die("Student not found");
}

$records = mysqli_query($conn, "
    SELECT *
    FROM student_subjects
    WHERE student_id='$id'
    ORDER BY sy, sem, subject_code
");

// Calculate academic statistics
$statsQuery = mysqli_query($conn, "
    SELECT 
        COUNT(*) as total_subjects,
        COUNT(CASE WHEN final > 0 THEN 1 END) as completed_subjects,
        COUNT(CASE WHEN final >= 75 THEN 1 END) as passed_subjects,
        COUNT(CASE WHEN final < 75 AND final > 0 THEN 1 END) as failed_subjects,
        SUM(CASE WHEN final > 0 THEN units END) as total_units,
        AVG(CASE WHEN final > 0 THEN final END) as average_grade,
        MAX(sy) as latest_sy,
        MAX(sem) as latest_sem
    FROM student_subjects
    WHERE student_id='$id'
");
$stats = mysqli_fetch_assoc($statsQuery);

// Calculate GWA (General Weighted Average)
$gwaQuery = mysqli_query($conn, "
    SELECT SUM(final * units) / SUM(units) as gwa
    FROM student_subjects
    WHERE student_id='$id' AND final > 0
");
$gwa = mysqli_fetch_assoc($gwaQuery);
?>

<div class="fade-in">
    <div class="max-w-6xl mx-auto">
        <!-- TOR Header -->
        <div class="card mb-6">
            <div class="card-body">
                <div class="text-center mb-6">
                    <h1 class="text-3xl font-bold">TRANSCRIPT OF RECORDS</h1>
                    <p class="text-secondary">Official Academic Record</p>
                    <div class="mt-2">
                        <span class="badge badge-primary">UNIVERSITY MANAGEMENT SYSTEM</span>
                    </div>
                </div>
                
                <!-- Student Information -->
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div>
                        <span class="text-secondary text-sm">Student ID</span>
                        <div class="font-semibold"><?= $student['student_id'] ?></div>
                    </div>
                    <div>
                        <span class="text-secondary text-sm">Full Name</span>
                        <div class="font-semibold"><?= htmlspecialchars($student['lname'] . ', ' . $student['fname']) ?></div>
                        <?php if ($student['mname']): ?>
                            <div class="text-sm text-secondary"><?= htmlspecialchars($student['mname']) ?></div>
                        <?php endif; ?>
                    </div>
                    <div>
                        <span class="text-secondary text-sm">Course</span>
                        <div class="font-semibold"><?= htmlspecialchars($student['course']) ?></div>
                    </div>
                    <div>
                        <span class="text-secondary text-sm">Major</span>
                        <div class="font-semibold"><?= htmlspecialchars($student['major'] ?? 'N/A') ?></div>
                    </div>
                </div>

                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                        <span class="text-secondary text-sm">Birth Date</span>
                        <div class="font-semibold"><?= date('F d, Y', strtotime($student['bdate'])) ?></div>
                    </div>
                    <div>
                        <span class="text-secondary text-sm">Address</span>
                        <div class="font-semibold"><?= htmlspecialchars($student['city'] ?? 'N/A') ?></div>
                    </div>
                    <div>
                        <span class="text-secondary text-sm">Latest SY</span>
                        <div class="font-semibold"><?= $stats['latest_sy'] ?? 'N/A' ?></div>
                    </div>
                    <div>
                        <span class="text-secondary text-sm">Latest Sem</span>
                        <div class="font-semibold"><?= $stats['latest_sem'] ?? 'N/A' ?></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Academic Summary -->
        <div class="card mb-6">
            <div class="card-header">
                <h2 class="card-title">📊 Academic Summary</h2>
            </div>
            <div class="card-body">
                <div class="grid grid-cols-2 md:grid-cols-5 gap-4">
                    <div class="text-center">
                        <div class="text-2xl font-bold"><?= $stats['total_subjects'] ?? 0 ?></div>
                        <div class="text-sm text-secondary">Total Subjects</div>
                    </div>
                    <div class="text-center">
                        <div class="text-2xl font-bold text-green-600"><?= $stats['completed_subjects'] ?? 0 ?></div>
                        <div class="text-sm text-green-500">Completed</div>
                    </div>
                    <div class="text-center">
                        <div class="text-2xl font-bold text-blue-600"><?= $stats['passed_subjects'] ?? 0 ?></div>
                        <div class="text-sm text-blue-500">Passed</div>
                    </div>
                    <div class="text-center">
                        <div class="text-2xl font-bold text-purple-600"><?= number_format($gwa['gwa'] ?? 0, 2) ?></div>
                        <div class="text-sm text-purple-500">GWA</div>
                    </div>
                    <div class="text-center">
                        <div class="text-2xl font-bold text-orange-600"><?= $stats['total_units'] ?? 0 ?></div>
                        <div class="text-sm text-orange-500">Total Units</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Academic Records Table -->
        <div class="card mb-6">
            <div class="card-header">
                <h2 class="card-title">📋 Academic Records</h2>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>School Year</th>
                                <th>Semester</th>
                                <th>Subject Code</th>
                                <th>Description</th>
                                <th>Units</th>
                                <th>Final Grade</th>
                                <th>Remarks</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $sy_total = 0;
                            $current_sy = '';
                            while($r = mysqli_fetch_assoc($records)) { 
                                // Add year separator
                                if ($current_sy != $r['sy']) {
                                    if ($current_sy != '') {
                                        echo '<tr><td colspan="8" class="text-center text-secondary font-semibold">SY ' . $current_sy . ' Total Units: ' . $sy_total . '</td></tr>';
                                    }
                                    $current_sy = $r['sy'];
                                    $sy_total = 0;
                                    echo '<tr><td colspan="8" class="text-center font-bold bg-gray-100">SCHOOL YEAR ' . $r['sy'] . '</td></tr>';
                                }
                                $sy_total += $r['units'];
                            ?>
                                <tr>
                                    <td><?= $r['sy'] ?></td>
                                    <td><?= $r['sem'] ?></td>
                                    <td>
                                        <div class="font-semibold"><?= htmlspecialchars($r['subject_code']) ?></div>
                                    </td>
                                    <td><?= htmlspecialchars($r['description']) ?></td>
                                    <td><?= $r['units'] ?></td>
                                    <td>
                                        <?php if ($r['final'] > 0): ?>
                                            <span class="badge badge-<?= $r['final'] >= 75 ? 'success' : 'danger' ?>">
                                                <?= number_format($r['final'], 2) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">Not Graded</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($r['remarks']): ?>
                                            <span class="badge badge-<?= $r['remarks'] == 'PASSED' ? 'success' : 'danger' ?>">
                                                <?= htmlspecialchars($r['remarks']) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($r['final'] > 0): ?>
                                            <span class="badge badge-<?= $r['final'] >= 75 ? 'success' : 'danger' ?>">
                                                <?= $r['final'] >= 75 ? '✓ Passed' : '✗ Failed' ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-warning">⏳ In Progress</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php } 
                            // Add last year total
                            if ($current_sy != '') {
                                echo '<tr><td colspan="8" class="text-center text-secondary font-semibold">SY ' . $current_sy . ' Total Units: ' . $sy_total . '</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Legend -->
        <div class="card mb-6">
            <div class="card-header">
                <h2 class="card-title">📖 Legend</h2>
            </div>
            <div class="card-body">
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                        <span class="badge badge-success">✓ Passed</span>
                        <p class="text-secondary mt-1">Grade ≥ 75</p>
                    </div>
                    <div>
                        <span class="badge badge-danger">✗ Failed</span>
                        <p class="text-secondary mt-1">Grade < 75</p>
                    </div>
                    <div>
                        <span class="badge badge-warning">⏳ In Progress</span>
                        <p class="text-secondary mt-1">Not yet graded</p>
                    </div>
                    <div>
                        <span class="badge badge-secondary">Not Graded</span>
                        <p class="text-secondary mt-1">No final grade</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer Information -->
        <div class="card">
            <div class="card-body">
                <div class="grid grid-cols-3 gap-6 text-center">
                    <div>
                        <div class="border-b-2 border-gray-300 pb-2 mb-2">
                            <strong>Certified by:</strong>
                        </div>
                        <div class="text-secondary">_________________________</div>
                        <div class="text-sm">Registrar</div>
                    </div>
                    <div>
                        <div class="border-b-2 border-gray-300 pb-2 mb-2">
                            <strong>Verified by:</strong>
                        </div>
                        <div class="text-secondary">_________________________</div>
                        <div class="text-sm">Department Head</div>
                    </div>
                    <div>
                        <div class="border-b-2 border-gray-300 pb-2 mb-2">
                            <strong>Approved by:</strong>
                        </div>
                        <div class="text-secondary">_________________________</div>
                        <div class="text-sm">Dean</div>
                    </div>
                </div>
                
                <div class="mt-6 text-center text-sm text-secondary">
                    <p>Generated on: <?= date('F d, Y h:i A') ?></p>
                    <p>This is an official transcript of records. Any alterations must be properly documented.</p>
                    <p class="mt-2"><strong>Note:</strong> This transcript is valid only when printed on official university letterhead.</p>
                </div>
            </div>
        </div>

        <!-- Print Button -->
        <div class="text-center mt-6">
            <button onclick="window.print()" class="btn btn-primary">
                🖨️ Print Transcript
            </button>
            <a href="records_dashboard.php" class="btn btn-outline ml-2">
                ← Back to Dashboard
            </a>
        </div>
    </div>
</div>

<style>
@media print {
    .text-center button, .text-center a {
        display: none !important;
    }
    
    .card {
        break-inside: avoid;
        page-break-inside: avoid;
        margin-bottom: 20px;
    }
    
    .table-responsive {
        overflow: visible !important;
    }
    
    body {
        background: white !important;
        padding: 20px !important;
    }
    
    .fade-in {
        animation: none !important;
    }
}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>