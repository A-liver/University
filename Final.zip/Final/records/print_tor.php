<?php
require_once __DIR__ . '/../includes/header.php';

$id = $_GET['id'];

$student = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT * FROM students WHERE student_id='$id'
"));

$records = mysqli_query($conn, "
    SELECT *
    FROM student_subjects
    WHERE student_id='$id'
    ORDER BY sy, sem
");
?>

<h2>TRANSCRIPT OF RECORDS</h2>

<p>Name: <?php echo $student['fname']." ".$student['lname']; ?></p>
<p>Student ID: <?php echo $student['student_id']; ?></p>

<hr>

<table border="1" cellpadding="5">
<tr>
    <th>SY</th>
    <th>SEM</th>
    <th>Subject</th>
    <th>Description</th>
    <th>Final</th>
    <th>Remarks</th>
</tr>

<?php while($r = mysqli_fetch_assoc($records)) { ?>
<tr>
    <td><?php echo $r['sy']; ?></td>
    <td><?php echo $r['sem']; ?></td>
    <td><?php echo $r['subject_code']; ?></td>
    <td><?php echo $r['description']; ?></td>
    <td><?php echo $r['final']; ?></td>
    <td><?php echo $r['remarks']; ?></td>
</tr>
<?php } ?>

</table>

<br>
<button onclick="window.print()">Print TOR</button>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>