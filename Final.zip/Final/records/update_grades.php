<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] != 'registrar' && $_SESSION['role'] != 'dean') {
    exit("Access denied");
}

$id = $_POST['id'];

$g1 = $_POST['g1'];
$g2 = $_POST['g2'];
$g3 = $_POST['g3'];
$final = $_POST['final'];
$remarks = mysqli_real_escape_string($conn, $_POST['remarks']);

mysqli_query($conn, "
    UPDATE student_subjects
    SET g1='$g1',
        g2='$g2',
        g3='$g3',
        final='$final',
        remarks='$remarks'
    WHERE id='$id'
");

echo "<script>
alert('Updated successfully');
window.location.href='records_dashboard.php';
</script>";
?>