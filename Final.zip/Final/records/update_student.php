<?php
require_once __DIR__ . '/../includes/header.php';

$id = $_POST['student_id'];

$fname = $_POST['fname'];
$mname = $_POST['mname'];
$lname = $_POST['lname'];
$bdate = $_POST['bdate'];
$city = $_POST['city'];

/* IMAGE */
if (!empty($_FILES['image']['name'])) {
    $img = time() . "_" . $_FILES['image']['name'];
    if (move_uploaded_file($_FILES['image']['tmp_name'], "../uploads/$img")) {

        mysqli_query($conn, "
            UPDATE students SET image_path='$img'
            WHERE student_id='$id'
        ");
    }
}

mysqli_query($conn, "
    UPDATE students
    SET fname='$fname',
        mname='$mname',
        lname='$lname',
        bdate='$bdate',
        city='$city'
    WHERE student_id='$id'
");

echo "<script>
alert('Student updated');
window.location.href='records_dashboard.php';
</script>";
?>