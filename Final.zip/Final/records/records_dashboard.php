<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'records' && $_SESSION['role'] != 'dean') {
    exit("Access denied");
}

/* SEARCH */
$key = $_GET['search'] ?? '';

$student = null;
$records = null;

if ($key) {

    $student = mysqli_fetch_assoc(mysqli_query($conn, "
        SELECT * FROM students
        WHERE student_id='$key'
        OR lname LIKE '%$key%'
        OR fname LIKE '%$key%'
        LIMIT 1
    "));

    if ($student) {
        $sid = $student['student_id'];

        $records = mysqli_query($conn, "
            SELECT *
            FROM student_subjects
            WHERE student_id='$sid'
            ORDER BY sy DESC, sem DESC
        ");
    }
}

// Get records statistics
$totalStudentsQuery = mysqli_query($conn, "SELECT COUNT(*) as total FROM students");
$studentStats = mysqli_fetch_assoc($totalStudentsQuery);

$totalRecordsQuery = mysqli_query($conn, "SELECT COUNT(*) as total FROM student_subjects");
$recordStats = mysqli_fetch_assoc($totalRecordsQuery);
?>

<div class="fade-in">
    <h1>Records Dashboard</h1>
    <p class="text-secondary">Manage student records and academic transcripts</p>

    <!-- Statistics Cards -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-value"><?= number_format($studentStats['total'] ?? 0) ?></div>
            <div class="stat-label">Total Students</div>
        </div>
        <div class="stat-card success">
            <div class="stat-value"><?= number_format($recordStats['total'] ?? 0) ?></div>
            <div class="stat-label">Academic Records</div>
        </div>
        <div class="stat-card warning">
            <div class="stat-value"><?= date('Y') ?></div>
            <div class="stat-label">Current Year</div>
        </div>
        <div class="stat-card danger">
            <div class="stat-value">Active</div>
            <div class="stat-label">System Status</div>
        </div>
    </div>

    <!-- Student Search -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">🔍 Student Records Search</h2>
        </div>
        <div class="card-body">
            <form method="GET" class="flex gap-4">
                <div class="flex-1">
                    <input type="text" name="search" class="form-input" placeholder="Search Student ID or Name" value="<?= htmlspecialchars($key) ?>">
                </div>
                <button type="submit" class="btn btn-primary">
                    🔍 Search Student
                </button>
            </form>
        </div>
    </div>

    <?php if ($student): ?>

        <!-- Student Profile -->
        <div class="card fade-in">
            <div class="card-header">
                <h3 class="card-title">👤 Student Profile</h3>
            </div>
            <div class="card-body">
                <form method="POST" action="update_student.php" enctype="multipart/form-data" class="grid grid-cols-2 gap-4">
                    <input type="hidden" name="student_id" value="<?php echo $student['student_id']; ?>">

                    <div>
                        <label class="form-label">First Name:</label>
                        <input type="text" name="fname" class="form-input" value="<?php echo htmlspecialchars($student['fname']); ?>">
                    </div>

                    <div>
                        <label class="form-label">Middle Name:</label>
                        <input type="text" name="mname" class="form-input" value="<?php echo htmlspecialchars($student['mname']); ?>">
                    </div>

                    <div>
                        <label class="form-label">Last Name:</label>
                        <input type="text" name="lname" class="form-input" value="<?php echo htmlspecialchars($student['lname']); ?>">
                    </div>

                    <div>
                        <label class="form-label">Birthdate:</label>
                        <input type="date" name="bdate" class="form-input" value="<?php echo $student['bdate']; ?>">
                    </div>

                    <div class="col-span-2">
                        <label class="form-label">Address:</label>
                        <input type="text" name="city" class="form-input" value="<?php echo htmlspecialchars($student['city']); ?>">
                    </div>

                    <div class="col-span-2">
                        <label class="form-label">Profile Picture:</label>
                        <input type="file" name="image" class="form-input">
                    </div>

                    <div class="col-span-2">
                        <button type="submit" class="btn btn-primary">
                            💾 Update Student Info
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Transcript of Records -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">📜 Transcript of Records</h3>
            </div>
            <div class="card-body">
                <div class="mb-4">
                    <a href="print_tor.php?id=<?php echo $student['student_id']; ?>" target="_blank" class="btn btn-success">
                        🖨️ Print TOR (PDF View)
                    </a>
                </div>

                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>SY</th>
                                <th>SEM</th>
                                <th>Subject</th>
                                <th>Description</th>
                                <th>G1</th>
                                <th>G2</th>
                                <th>G3</th>
                                <th>Final</th>
                                <th>Remarks</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($r = mysqli_fetch_assoc($records)) { ?>
                                <tr>
                                    <td><span class="badge badge-primary"><?= $r['sy'] ?></span></td>
                                    <td><span class="badge badge-secondary"><?= $r['sem'] ?></span></td>
                                    <td><?= htmlspecialchars($r['subject_code']) ?></td>
                                    <td><?= htmlspecialchars($r['description']) ?></td>

                                    <form method="POST" action="update_grades.php">
                                        <td><input type="text" name="g1" class="form-input" value="<?php echo $r['g1']; ?>" style="width: 60px;"></td>
                                        <td><input type="text" name="g2" class="form-input" value="<?php echo $r['g2']; ?>" style="width: 60px;"></td>
                                        <td><input type="text" name="g3" class="form-input" value="<?php echo $r['g3']; ?>" style="width: 60px;"></td>
                                        <td><input type="text" name="final" class="form-input" value="<?php echo $r['final']; ?>" style="width: 60px;"></td>
                                        <td><input type="text" name="remarks" class="form-input" value="<?php echo $r['remarks']; ?>" style="width: 80px;"></td>

                                        <td>
                                            <input type="hidden" name="id" value="<?php echo $r['id']; ?>">
                                            <button type="submit" class="btn btn-success btn-sm">💾 Save</button>
                                        </td>
                                    </form>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    <?php elseif ($key): ?>
        <div class="alert alert-error">
            <strong>Student Not Found:</strong> No student records match your search criteria.
        </div>
    <?php endif; ?>

    <!-- Quick Actions -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">⚡ Quick Actions</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-3 gap-4">
                <a href="#" class="btn btn-primary">
                    📊 Generate Reports
                </a>
                <a href="#" onclick="window.print()" class="btn btn-outline">
                    🖨️ Print Dashboard
                </a>
                <a href="../auth/logout.php" class="btn btn-danger">
                    🚪 Logout
                </a>
            </div>
        </div>
    </div>

    <!-- Important Information -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">📋 Records Management</h2>
        </div>
        <div class="card-body">
            <div class="alert alert-info">
                <strong>Grade Updates:</strong> Ensure all grade entries are accurate before saving. Changes are logged for audit purposes.
            </div>
            <div class="alert alert-warning">
                <strong>Student Information:</strong> Keep student profiles up-to-date for official records and transcripts.
            </div>
            <p class="text-secondary">
                For transcript requests or record verification, contact the registrar's office.
            </p>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>