<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'records' && $_SESSION['role'] != 'dean') {
    exit("Access denied");
}

/* SEARCH */
$key = $_GET['search'] ?? '';

$student = null;
$records = null;

if ($key) {

    $student = mysqli_fetch_assoc(mysqli_query($conn, "
        SELECT * FROM students
        WHERE student_id='$key'
        OR lname LIKE '%$key%'
        OR fname LIKE '%$key%'
        LIMIT 1
    "));

    if ($student) {
        $sid = $student['student_id'];

        $records = mysqli_query($conn, "
            SELECT *
            FROM student_subjects
            WHERE student_id='$sid'
            ORDER BY sy DESC, sem DESC
        ");
    }
}
?>

<h2>Records Dashboard</h2>

<!-- SEARCH -->
<form method="GET">
    <input type="text" name="search" placeholder="Search Student ID or Name">
    <button>Search</button>
</form>

<hr>

<?php if ($student): ?>

<h3>Student Profile</h3>

<form method="POST" action="update_student.php" enctype="multipart/form-data">

    <input type="hidden" name="student_id" value="<?php echo $student['student_id']; ?>">

    <p>
        First Name:
        <input type="text" name="fname" value="<?php echo $student['fname']; ?>">
    </p>

    <p>
        Middle Name:
        <input type="text" name="mname" value="<?php echo $student['mname']; ?>">
    </p>

    <p>
        Last Name:
        <input type="text" name="lname" value="<?php echo $student['lname']; ?>">
    </p>

    <p>
        Birthdate:
        <input type="date" name="bdate" value="<?php echo $student['bdate']; ?>">
    </p>

    <p>
        Address:
        <input type="text" name="city" value="<?php echo $student['city']; ?>">
    </p>

    <p>
        Picture:
        <input type="file" name="image">
    </p>

    <button type="submit">Update Student Info</button>

</form>

<hr>

<h3>Transcript of Records</h3>

<a href="print_tor.php?id=<?php echo $student['student_id']; ?>" target="_blank">
    <button>Print TOR (PDF View)</button>
</a>

<table border="1" cellpadding="5">

<tr>
    <th>SY</th>
    <th>SEM</th>
    <th>Subject</th>
    <th>Description</th>
    <th>G1</th>
    <th>G2</th>
    <th>G3</th>
    <th>Final</th>
    <th>Remarks</th>
    <th>Action</th>
</tr>

<?php while ($r = mysqli_fetch_assoc($records)) { ?>

<tr>
    <td><?php echo $r['sy']; ?></td>
    <td><?php echo $r['sem']; ?></td>
    <td><?php echo $r['subject_code']; ?></td>
    <td><?php echo $r['description']; ?></td>

    <form method="POST" action="update_grades.php">

    <td><input type="text" name="g1" value="<?php echo $r['g1']; ?>"></td>
    <td><input type="text" name="g2" value="<?php echo $r['g2']; ?>"></td>
    <td><input type="text" name="g3" value="<?php echo $r['g3']; ?>"></td>
    <td><input type="text" name="final" value="<?php echo $r['final']; ?>"></td>
    <td><input type="text" name="remarks" value="<?php echo $r['remarks']; ?>"></td>

    <td>
        <input type="hidden" name="id" value="<?php echo $r['id']; ?>">
        <button type="submit">Save</button>
    </td>

    </form>

</tr>

<?php } ?>

</table>

<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>