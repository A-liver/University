<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'student') {
    exit("Access denied");
}

$student_id = $_SESSION['student_id'] ?? 0;
$type = $_GET['type'] ?? '';

if (!$student_id || !$type) {
    exit("Invalid request");
}

$student = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT * FROM students WHERE student_id='$student_id'
"));

$sy = $student['sy'];
$sem = $student['sem'];

/* TOTAL BILL */
$subjects = mysqli_query($conn, "
    SELECT units FROM student_subjects
    WHERE student_id='$student_id' AND sy='$sy' AND sem='$sem'
");

$total_units = 0;
while ($s = mysqli_fetch_assoc($subjects)) {
    $total_units += $s['units'];
}

$tuition = ($total_units / 3) * 300;

$billing = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT billing_id FROM billing_master
    WHERE student_id='$student_id' AND sy='$sy' AND sem='$sem'
"));

$billing_id = $billing['billing_id'] ?? 0;

$other_total = 0;

if ($billing_id) {
    $fees = mysqli_query($conn, "
        SELECT amount FROM billing_details WHERE billing_id='$billing_id'
    ");

    while ($f = mysqli_fetch_assoc($fees)) {
        $other_total += $f['amount'];
    }
}

$total_bill = $tuition + $other_total;

/* PAYMENTS */
$paid = 0;

if ($billing_id) {
    $payments = mysqli_query($conn, "
        SELECT amount_paid FROM payments WHERE billing_id='$billing_id'
    ");

    while ($p = mysqli_fetch_assoc($payments)) {
        $paid += $p['amount_paid'];
    }
}

$one_third = $total_bill / 3;

$allowed = false;

if ($type == "prelim") {
    $allowed = $paid >= $one_third;
} elseif ($type == "midterm") {
    $allowed = $paid >= ($one_third * 2);
} elseif ($type == "final") {
    $allowed = $paid >= $total_bill;
}
?>

<h2><?php echo strtoupper($type); ?> EXAM PERMIT</h2>

<p>Name: <?php echo $student['fname']." ".$student['lname']; ?></p>
<p>Student ID: <?php echo $student_id; ?></p>
<p>Course: <?php echo $student['course']; ?></p>
<p>SY: <?php echo $sy; ?> | SEM: <?php echo $sem; ?></p>

<hr>

<p>Total Bill: ₱<?php echo number_format($total_bill,2); ?></p>
<p>Paid: ₱<?php echo number_format($paid,2); ?></p>

<hr>

<h2>
    STATUS:
    <?php echo $allowed ? "ALLOWED" : "NOT ALLOWED"; ?>
</h2>

<?php if ($allowed): ?>
    <button onclick="window.print()">PRINT</button>
<?php else: ?>
    <p>You are not eligible for this permit.</p>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>