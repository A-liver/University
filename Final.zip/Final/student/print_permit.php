<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'student') {
    exit("Access denied");
}

$student_id = $_SESSION['student_id'] ?? 0;
$type = $_GET['type'] ?? '';

if (!$student_id || !$type) {
    exit("Invalid request");
}

$student = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT * FROM students WHERE student_id='$student_id'
"));

$sy = $student['sy'];
$sem = $student['sem'];

/* TOTAL BILL */
$subjects = mysqli_query($conn, "
    SELECT units FROM student_subjects
    WHERE student_id='$student_id' AND sy='$sy' AND sem='$sem'
");

$total_units = 0;
while ($s = mysqli_fetch_assoc($subjects)) {
    $total_units += $s['units'];
}

$tuition = ($total_units / 3) * 300;

$billing = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT billing_id FROM billing_master
    WHERE student_id='$student_id' AND sy='$sy' AND sem='$sem'
"));

$billing_id = $billing['billing_id'] ?? 0;

$other_total = 0;

if ($billing_id) {
    $fees = mysqli_query($conn, "
        SELECT amount FROM billing_details WHERE billing_id='$billing_id'
    ");

    while ($f = mysqli_fetch_assoc($fees)) {
        $other_total += $f['amount'];
    }
}

$total_bill = $tuition + $other_total;

/* PAYMENTS */
$paid = 0;

if ($billing_id) {
    $payments = mysqli_query($conn, "
        SELECT amount_paid FROM payments WHERE billing_id='$billing_id'
    ");

    while ($p = mysqli_fetch_assoc($payments)) {
        $paid += $p['amount_paid'];
    }
}

$one_third = $total_bill / 3;

$allowed = false;

if ($type == "prelim") {
    $allowed = $paid >= $one_third;
} elseif ($type == "midterm") {
    $allowed = $paid >= ($one_third * 2);
} elseif ($type == "final") {
    $allowed = $paid >= $total_bill;
}
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 style="font-size: 2rem; font-weight: 700; background: linear-gradient(135deg, var(--primary-color), var(--primary-dark)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                <i class="fas fa-print"></i> <?php echo strtoupper($type); ?> EXAM PERMIT
            </h1>
            <p class="text-secondary">Print your examination permit for <?php echo ucfirst($type); ?> exams</p>
        </div>
        <div class="flex gap-2">
            <a href="exam_permit.php" class="btn btn-outline">
                <i class="fas fa-arrow-left"></i> Back to Exam Permit
            </a>
            <button onclick="window.print()" class="btn btn-primary">
                <i class="fas fa-print"></i> Print Permit
            </button>
        </div>
    </div>

    <!-- Permit Content -->
    <div class="card" id="permit-content">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-certificate"></i> Examination Permit
            </h2>
            <p class="text-sm text-secondary">Official permit for <?php echo ucfirst($type); ?> examination</p>
        </div>
        <div class="card-body">
            <!-- Student Information -->
            <div class="mb-6">
                <h3 class="font-semibold mb-4 text-lg">
                    <i class="fas fa-user"></i> Student Information
                </h3>
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div class="bg-blue-50 p-3 rounded-lg border border-blue-200">
                        <span class="text-secondary text-sm text-blue-600">Student ID</span>
                        <div class="font-semibold text-blue-800"><?php echo $student_id; ?></div>
                    </div>
                    <div class="bg-green-50 p-3 rounded-lg border border-green-200">
                        <span class="text-secondary text-sm text-green-600">Full Name</span>
                        <div class="font-semibold text-green-800"><?php echo htmlspecialchars($student['fname']." ".$student['lname']); ?></div>
                    </div>
                    <div class="bg-purple-50 p-3 rounded-lg border border-purple-200">
                        <span class="text-secondary text-sm text-purple-600">Course</span>
                        <div class="font-semibold text-purple-800"><?php echo htmlspecialchars($student['course']); ?></div>
                    </div>
                    <div class="bg-orange-50 p-3 rounded-lg border border-orange-200">
                        <span class="text-secondary text-sm text-orange-600">Academic Year</span>
                        <div class="font-semibold text-orange-800"><?php echo htmlspecialchars($sy); ?> | SEM <?php echo htmlspecialchars($sem); ?></div>
                    </div>
                </div>
            </div>

            <!-- Payment Information -->
            <div class="mb-6">
                <h3 class="font-semibold mb-4 text-lg">
                    <i class="fas fa-credit-card"></i> Payment Information
                </h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="bg-gray-50 p-4 rounded-lg border border-gray-200">
                        <span class="text-secondary text-sm text-gray-600">Total Bill</span>
                        <div class="font-semibold text-gray-800 text-xl">₱<?php echo number_format($total_bill,2); ?></div>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-lg border border-gray-200">
                        <span class="text-secondary text-sm text-gray-600">Amount Paid</span>
                        <div class="font-semibold text-green-800 text-xl">₱<?php echo number_format($paid,2); ?></div>
                    </div>
                </div>
            </div>

            <!-- Permit Status -->
            <div class="text-center">
                <div class="inline-block p-6 rounded-lg border-2 <?php echo $allowed ? 'border-green-500 bg-green-50' : 'border-red-500 bg-red-50'; ?>">
                    <div class="text-4xl mb-3">
                        <?php echo $allowed ? '✅' : '❌'; ?>
                    </div>
                    <h3 class="font-bold text-2xl mb-2 <?php echo $allowed ? 'text-green-800' : 'text-red-800'; ?>">
                        STATUS: <?php echo $allowed ? "ALLOWED" : "NOT ALLOWED"; ?>
                    </h3>
                    <p class="text-sm <?php echo $allowed ? 'text-green-600' : 'text-red-600'; ?>">
                        <?php echo $allowed ? "You are permitted to take the $type examination" : "Payment requirements not met for $type examination"; ?>
                    </p>
                </div>
            </div>

            <!-- Permit Details -->
            <div class="mt-6 pt-6 border-t border-gray-200">
                <div class="text-sm text-gray-600">
                    <p><strong>Permit Type:</strong> <?php echo strtoupper($type); ?> Examination</p>
                    <p><strong>Date Issued:</strong> <?php echo date('F d, Y h:i A'); ?></p>
                    <p><strong>Valid For:</strong> <?php echo ucfirst($type); ?> Examination Period</p>
                </div>
            </div>

            <!-- Signature Lines -->
            <div class="mt-8 grid grid-cols-1 md:grid-cols-2 gap-8">
                <div class="text-center">
                    <div class="border-b-2 border-gray-400 pb-2 mb-2">
                        <span class="text-sm text-gray-600">Student Signature</span>
                    </div>
                    <p class="text-sm text-gray-500">Over Printed Name</p>
                </div>
                <div class="text-center">
                    <div class="border-b-2 border-gray-400 pb-2 mb-2">
                        <span class="text-sm text-gray-600">Registrar's Signature</span>
                    </div>
                    <p class="text-sm text-gray-500">Over Printed Name</p>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
@media print {
    body {
        background: white !important;
        padding: 20px !important;
    }
    
    .flex.justify-between.items-center.mb-6 {
        display: none !important;
    }
    
    .card {
        box-shadow: none !important;
        border: 2px solid #000 !important;
        page-break-inside: avoid;
    }
    
    .btn {
        display: none !important;
    }
}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>