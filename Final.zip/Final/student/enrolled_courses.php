<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] !== 'student') {
    exit("Access denied");
}

$student_id = $_SESSION['student_id'];

$cn = $_GET['id'] ?? null;
if (!$cn) exit("No subject selected");

/* =========================
   GET STUDENT INFO FIRST
========================= */
$studentQuery = mysqli_query($conn, "
    SELECT sy, sem, course
    FROM students
    WHERE student_id='$student_id'
    LIMIT 1
");

if (!$studentQuery) {
    die("Student query failed: " . mysqli_error($conn));
}

$student = mysqli_fetch_assoc($studentQuery);

$sy = $student['sy'];
$sem = $student['sem'];
$course = $student['course'];

/* =========================
   GET SUBJECT
========================= */
$subjectQuery = mysqli_query($conn, "
    SELECT * 
    FROM subjectssem120182019 
    WHERE CN='$cn'
");

if (!$subjectQuery) {
    die("Subject query failed: " . mysqli_error($conn));
}

$subject = mysqli_fetch_assoc($subjectQuery);

if (!$subject) exit("Subject not found");

$subject_code = $subject['SUBJECT'];
$description  = $subject['DESC'];
$units        = (int)$subject['UNIT'];
$room         = $subject['ROOM'];
$instructor   = $subject['INSTRUCTOR'];
$term         = $subject['TERM'];

/* =========================
   CHECK DUPLICATE
========================= */
$check = mysqli_query($conn, "
    SELECT id FROM student_subjects 
    WHERE student_id='$student_id'
    AND subject_code='$subject_code'
    AND sy='$sy'
    AND sem='$sem'
");

if (mysqli_num_rows($check) > 0) {
    echo "<script>
        alert('Already enrolled!');
        window.location.href='add_subject.php';
    </script>";
    exit;
}

/* =========================
   INSERT SUBJECT
========================= */
$insert = mysqli_query($conn, "
INSERT INTO student_subjects (
    student_id, cn, course,
    subject_code, description,
    units, room, instructor,
    term, sem, sy
) VALUES (
    '$student_id',
    '$cn',
    '$course',
    '$subject_code',
    '$description',
    '$units',
    '$room',
    '$instructor',
    '$term',
    '$sem',
    '$sy'
)
");

if (!$insert) {
    die("Insert failed: " . mysqli_error($conn));
}

/* =========================
   UPDATE BILLING AFTER INSERT
========================= */

/* 1. GET TOTAL UNITS */
$unitQ = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT SUM(units) AS total_units
    FROM student_subjects
    WHERE student_id='$student_id'
    AND sy='$sy'
    AND sem='$sem'
"));

$total_units = $unitQ['total_units'] ?? 0;

/* 2. RATE */
$rate_per_3_units = 300;

/* 3. TUITION */
$tuition = ($total_units / 3) * $rate_per_3_units;

/* 4. GET BILLING MASTER */
$bm = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT billing_id 
    FROM billing_master
    WHERE student_id='$student_id'
    AND sy='$sy'
    AND sem='$sem'
    LIMIT 1
"));

if ($bm) {
    $billing_id = $bm['billing_id'];

    /* 5. UPDATE BILLING */
    mysqli_query($conn, "
        UPDATE billing_master
        SET total_units='$total_units',
            total_amount='$tuition'
        WHERE billing_id='$billing_id'
    ");
}

echo "<script>
    alert('Subject added successfully!');
    window.location.href='student_dashboard.php';
</script>";
?>