<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'student') {
    exit("Access denied");
}

/* =========================
   USE REAL STUDENT ID
========================= */
if (!isset($_SESSION['student_id'])) {
    die("Session error: student_id not found. Please login again.");
}

$student_id = $_SESSION['student_id'];

/* =========================
   STUDENT INFO
========================= */
$studentQuery = mysqli_query($conn, "
    SELECT * FROM students WHERE student_id='$student_id'
");

if (!$studentQuery) {
    die("Student query error: " . mysqli_error($conn));
}

$student = mysqli_fetch_assoc($studentQuery);

if (!$student) {
    exit("Student not found");
}

$sy = $student['sy'];
$sem = $student['sem'];

echo "<h2>Student Dashboard - Billing</h2>";
echo "<p><b>{$student['fname']} {$student['lname']}</b></p>";
echo "<p>SY: $sy | SEM: $sem</p>";

/* =========================
   SUBJECTS
========================= */
$subjects = mysqli_query($conn, "
    SELECT subject_code, description, units
    FROM student_subjects
    WHERE student_id='$student_id'
    AND sy='$sy'
    AND sem='$sem'
");

if (!$subjects) {
    die("Subjects query error: " . mysqli_error($conn));
}

$total_units = 0;

echo "<h3>Enrolled Subjects</h3>";
echo "<table border='1'>
<tr>
    <th>Subject</th>
    <th>Description</th>
    <th>Units</th>
</tr>";

while ($s = mysqli_fetch_assoc($subjects)) {

    $total_units += $s['units'];

    echo "<tr>
        <td>{$s['subject_code']}</td>
        <td>{$s['description']}</td>
        <td>{$s['units']}</td>
    </tr>";
}

echo "</table>";

/* =========================
   TUITION
========================= */
$tuition = ($total_units / 3) * 300;

/* =========================
   BILLING MASTER
========================= */
$billingQuery = mysqli_query($conn, "
    SELECT * FROM billing_master
    WHERE student_id='$student_id'
    AND sy='$sy'
    AND sem='$sem'
");

if (!$billingQuery) {
    die("Billing query error: " . mysqli_error($conn));
}

$billing = mysqli_fetch_assoc($billingQuery);
$billing_id = $billing['billing_id'] ?? null;

/* =========================
   OTHER FEES
========================= */
$other_total = 0;

echo "<h3>Other Fees</h3>";

if ($billing_id) {

    $fees = mysqli_query($conn, "
        SELECT description, amount
        FROM billing_details
        WHERE billing_id='$billing_id'
    ");

    if (!$fees) {
        die("Fees query error: " . mysqli_error($conn));
    }

    echo "<table border='1'>
    <tr><th>Description</th><th>Amount</th></tr>";

    while ($f = mysqli_fetch_assoc($fees)) {

        echo "<tr>
            <td>{$f['description']}</td>
            <td>{$f['amount']}</td>
        </tr>";

        $other_total += $f['amount'];
    }

    echo "</table>";

} else {
    echo "<p>No billing record found.</p>";
}

/* =========================
   TOTAL
========================= */
$total_bill = $tuition + $other_total;

echo "<h3>Tuition: ₱$tuition</h3>";
echo "<h3>Other Fees: ₱$other_total</h3>";
echo "<h2>Total Bill: ₱$total_bill</h2>";

/* =========================
   PAYMENTS
========================= */
$paid = 0;

if ($billing_id) {

    $payments = mysqli_query($conn, "
        SELECT * FROM payments
        WHERE billing_id='$billing_id'
        ORDER BY payment_date DESC
    ");

    if (!$payments) {
        die("Payments query error: " . mysqli_error($conn));
    }

    echo "<h3>Payment History</h3>";
    echo "<table border='1'>
    <tr>
        <th>Date</th>
        <th>Amount</th>
    </tr>";

    while ($p = mysqli_fetch_assoc($payments)) {

        echo "<tr>
            <td>{$p['payment_date']}</td>
            <td>{$p['amount_paid']}</td>
        </tr>";

        $paid += $p['amount_paid'];
    }

    echo "</table>";
}

/* =========================
   BALANCE
========================= */
$balance = $total_bill - $paid;

echo "<h2>Paid: ₱$paid</h2>";
echo "<h2>Balance: ₱$balance</h2>";

/* =========================
   STATUS
========================= */
if ($paid <= 0) {
    $status = "UNPAID";
} elseif ($paid < $total_bill) {
    $status = "PARTIAL";
} else {
    $status = "PAID";
}

echo "<h2>Status: $status</h2>";
echo "<br><button onclick='printBilling()'> Print Billing</button>";
echo "<script>function printBilling() {window.print()};</script>";

?>



<?php require_once __DIR__ . '/../includes/footer.php'; ?>