<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'student') {
    exit("Access denied");
}

/* =========================
   USE REAL STUDENT ID
========================= */
if (!isset($_SESSION['student_id'])) {
    die("Session error: student_id not found. Please login again.");
}

$student_id = $_SESSION['student_id'];

/* =========================
   STUDENT INFO
========================= */
$studentQuery = mysqli_query($conn, "
    SELECT * FROM students WHERE student_id='$student_id'
");

if (!$studentQuery) {
    die("Student query error: " . mysqli_error($conn));
}

$student = mysqli_fetch_assoc($studentQuery);

if (!$student) {
    exit("Student not found");
}

$sy = $student['sy'];
$sem = $student['sem'];

/* =========================
   SUBJECTS
========================= */
$subjects = mysqli_query($conn, "
    SELECT subject_code, description, units
    FROM student_subjects
    WHERE student_id='$student_id'
    AND sy='$sy'
    AND sem='$sem'
");

if (!$subjects) {
    die("Subjects query error: " . mysqli_error($conn));
}

$total_units = 0;

/* =========================
   TUITION
========================= */
$tuition = ($total_units / 3) * 300;

/* =========================
   BILLING MASTER
========================= */
$billingQuery = mysqli_query($conn, "
    SELECT * FROM billing_master
    WHERE student_id='$student_id'
    AND sy='$sy'
    AND sem='$sem'
");

if (!$billingQuery) {
    die("Billing query error: " . mysqli_error($conn));
}

$billing = mysqli_fetch_assoc($billingQuery);
$billing_id = $billing['billing_id'] ?? null;

/* =========================
   OTHER FEES
========================= */
$other_total = 0;
$fees_data = [];

if ($billing_id) {
    $fees = mysqli_query($conn, "
        SELECT description, amount
        FROM billing_details
        WHERE billing_id='$billing_id'
    ");

    if (!$fees) {
        die("Fees query error: " . mysqli_error($conn));
    }

    while ($f = mysqli_fetch_assoc($fees)) {
        $fees_data[] = $f;
        $other_total += $f['amount'];
    }
}

/* =========================
   TOTAL
========================= */
$total_bill = $tuition + $other_total;

/* =========================
   PAYMENTS
========================= */
$paid = 0;
$payments_data = [];

if ($billing_id) {
    $payments = mysqli_query($conn, "
        SELECT * FROM payments
        WHERE billing_id='$billing_id'
        ORDER BY payment_date DESC
    ");

    if (!$payments) {
        die("Payments query error: " . mysqli_error($conn));
    }

    while ($p = mysqli_fetch_assoc($payments)) {
        $payments_data[] = $p;
        $paid += $p['amount_paid'];
    }
}

/* =========================
   BALANCE
========================= */
$balance = $total_bill - $paid;

/* =========================
   STATUS
========================= */
if ($paid <= 0) {
    $status = "UNPAID";
    $status_class = "danger";
} elseif ($paid < $total_bill) {
    $status = "PARTIAL";
    $status_class = "warning";
} else {
    $status = "PAID";
    $status_class = "success";
}
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1>💳 Student Billing</h1>
            <p class="text-secondary">View your billing and payment information</p>
        </div>
        <div class="flex gap-2">
            <button onclick="printBilling()" class="btn btn-outline">
                🖨️ Print Billing
            </button>
            <a href="student_dashboard.php" class="btn btn-secondary">
                ← Back to Dashboard
            </a>
        </div>
    </div>

    <!-- Student Information -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">👤 Student Information</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                    <span class="text-secondary text-sm">Student ID</span>
                    <div class="font-semibold"><?= $student_id ?></div>
                </div>
                <div>
                    <span class="text-secondary text-sm">Full Name</span>
                    <div class="font-semibold"><?= htmlspecialchars($student['fname'] . ' ' . $student['lname']) ?></div>
                </div>
                <div>
                    <span class="text-secondary text-sm">Academic Year</span>
                    <div class="font-semibold"><?= htmlspecialchars($sy) ?> - <?= htmlspecialchars($sem) ?></div>
                </div>
                <div>
                    <span class="text-secondary text-sm">Payment Status</span>
                    <div class="font-semibold">
                        <span class="badge badge-<?= $status_class ?>"><?= $status ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Billing Summary -->
    <div class="stats-grid mb-6">
        <div class="stat-card">
            <div class="stat-value"><?= mysqli_num_rows($subjects) ?></div>
            <div class="stat-label">Enrolled Subjects</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?= $total_units ?></div>
            <div class="stat-label">Total Units</div>
        </div>
        <div class="stat-card success">
            <div class="stat-value">₱<?= number_format($tuition, 2) ?></div>
            <div class="stat-label">Tuition Fee</div>
        </div>
        <div class="stat-card danger">
            <div class="stat-value">₱<?= number_format($balance, 2) ?></div>
            <div class="stat-label">Remaining Balance</div>
        </div>
    </div>

    <!-- Enrolled Subjects -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">📚 Enrolled Subjects</h2>
        </div>
        <div class="card-body">
            <?php if (mysqli_num_rows($subjects) > 0): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Subject Code</th>
                                <th>Description</th>
                                <th>Units</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            mysqli_data_seek($subjects, 0); // Reset pointer
                            while ($s = mysqli_fetch_assoc($subjects)) {
                                $total_units += $s['units'];
                            ?>
                                <tr>
                                    <td><span class="badge badge-primary"><?= htmlspecialchars($s['subject_code']) ?></span></td>
                                    <td><?= htmlspecialchars($s['description']) ?></td>
                                    <td><?= $s['units'] ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    No subjects enrolled for the current semester.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Fee Breakdown -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">💰 Fee Breakdown</h2>
        </div>
        <div class="card-body">
            <div class="space-y-3">
                <div class="flex justify-between items-center p-3 bg-gray-50 rounded">
                    <span class="font-semibold">Tuition Fee (<?= $total_units ?> units × ₱100 per unit)</span>
                    <span class="font-semibold">₱<?= number_format($tuition, 2) ?></span>
                </div>
                
                <?php if (!empty($fees_data)): ?>
                    <?php foreach ($fees_data as $fee): ?>
                        <div class="flex justify-between items-center p-3 bg-gray-50 rounded">
                            <span><?= htmlspecialchars($fee['description']) ?></span>
                            <span>₱<?= number_format($fee['amount'], 2) ?></span>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
                
                <div class="flex justify-between items-center p-3 bg-primary text-white rounded font-bold">
                    <span>Total Amount Due</span>
                    <span>₱<?= number_format($total_bill, 2) ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Payment History -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">📋 Payment History</h2>
        </div>
        <div class="card-body">
            <?php if (!empty($payments_data)): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Payment Date</th>
                                <th>Amount Paid</th>
                                <th>Receipt #</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($payments_data as $payment): ?>
                                <tr>
                                    <td><?= date('F d, Y h:i A', strtotime($payment['payment_date'])) ?></td>
                                    <td class="text-green-600 font-semibold">₱<?= number_format($payment['amount_paid'], 2) ?></td>
                                    <td>
                                        <span class="badge badge-primary">#<?= str_pad($payment['payment_id'], 6, '0', STR_PAD_LEFT) ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    No payment records found.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Payment Summary -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">📊 Payment Summary</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div class="text-center p-4 bg-gray-50 rounded">
                    <div class="text-2xl font-bold text-gray-600">₱<?= number_format($total_bill, 2) ?></div>
                    <div class="text-sm text-gray-500">Total Bill</div>
                </div>
                <div class="text-center p-4 bg-green-50 rounded">
                    <div class="text-2xl font-bold text-green-600">₱<?= number_format($paid, 2) ?></div>
                    <div class="text-sm text-green-500">Amount Paid</div>
                </div>
                <div class="text-center p-4 bg-red-50 rounded">
                    <div class="text-2xl font-bold text-red-600">₱<?= number_format($balance, 2) ?></div>
                    <div class="text-sm text-red-500">Remaining Balance</div>
                </div>
            </div>
            
            <div class="mt-4 text-center">
                <span class="badge badge-<?= $status_class ?> text-lg px-4 py-2">
                    <?= $status ?>
                </span>
            </div>
        </div>
    </div>
</div>

<script>
function printBilling() {
    window.print();
}

// Add print styles
const printStyles = document.createElement('style');
printStyles.textContent = `
    @media print {
        .card-header button,
        .flex.gap-2 {
            display: none !important;
        }
        
        .card {
            break-inside: avoid;
            page-break-inside: avoid;
        }
        
        .table-responsive {
            overflow: visible !important;
        }
        
        body {
            background: white !important;
        }
    }
`;
document.head.appendChild(printStyles);
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>