<?php
require_once __DIR__ . '/../includes/header.php';

/* 🔒 SECURITY */
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'student') {
    exit("Access denied");
}

/* ✅ USE REAL student_id */
$student_id = $_SESSION['student_id'] ?? 0;

if (!$student_id) {
    exit("Session error: student_id not set.");
}

/* =========================
   GET STUDENT INFO
========================= */
$student = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT * FROM students 
    WHERE student_id='$student_id'
"));

if (!$student) {
    exit("Student not found");
}

/* =========================
   GET ALL GRADES (ALL SY/SEM)
========================= */
$grades = mysqli_query($conn, "
    SELECT 
        subject_code,
        description,
        cn,
        course,
        sy,
        sem,
        g1,
        g2,
        g3,
        final,
        remarks
    FROM student_subjects
    WHERE student_id='$student_id'
    ORDER BY sy DESC, sem DESC, subject_code ASC
");

if (!$grades) {
    die("Query Error: " . mysqli_error($conn));
}

/* =========================
   CALCULATE STATISTICS
========================= */
$statsQuery = mysqli_query($conn, "
    SELECT 
        COUNT(*) as total_subjects,
        COUNT(CASE WHEN final > 0 THEN 1 END) as graded_subjects,
        COUNT(CASE WHEN final >= 75 THEN 1 END) as passed_subjects,
        COUNT(CASE WHEN final < 75 AND final > 0 THEN 1 END) as failed_subjects,
        AVG(CASE WHEN final > 0 THEN final END) as average_grade,
        MAX(CASE WHEN final > 0 THEN final END) as highest_grade,
        MIN(CASE WHEN final > 0 THEN final END) as lowest_grade
    FROM student_subjects
    WHERE student_id='$student_id'
");

$stats = mysqli_fetch_assoc($statsQuery);
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1>📊 My Grades</h1>
            <p class="text-secondary">View your academic performance and grades</p>
        </div>
        <div class="flex gap-2">
            <button onclick="window.print()" class="btn btn-outline">
                🖨️ Print Grades
            </button>
            <a href="student_dashboard.php" class="btn btn-secondary">
                ← Dashboard
            </a>
        </div>
    </div>

    <!-- Student Information -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">👤 Student Information</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                    <span class="text-secondary text-sm">Student ID</span>
                    <div class="font-semibold"><?= $student_id ?></div>
                </div>
                <div>
                    <span class="text-secondary text-sm">Full Name</span>
                    <div class="font-semibold"><?= htmlspecialchars($student['fname'] . ' ' . $student['lname']) ?></div>
                </div>
                <div>
                    <span class="text-secondary text-sm">Course</span>
                    <div class="font-semibold"><?= htmlspecialchars($student['course']) ?></div>
                </div>
                <div>
                    <span class="text-secondary text-sm">Major</span>
                    <div class="font-semibold"><?= htmlspecialchars($student['major'] ?? 'Not specified') ?></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Academic Statistics -->
    <div class="stats-grid mb-6">
        <div class="stat-card">
            <div class="stat-value"><?= $stats['total_subjects'] ?? 0 ?></div>
            <div class="stat-label">Total Subjects</div>
        </div>
        <div class="stat-card success">
            <div class="stat-value"><?= $stats['passed_subjects'] ?? 0 ?></div>
            <div class="stat-label">Passed</div>
        </div>
        <div class="stat-card danger">
            <div class="stat-value"><?= $stats['failed_subjects'] ?? 0 ?></div>
            <div class="stat-label">Failed</div>
        </div>
        <div class="stat-card warning">
            <div class="stat-value"><?= number_format($stats['average_grade'] ?? 0, 2) ?></div>
            <div class="stat-label">Average Grade</div>
        </div>
    </div>

    <!-- Grade Performance Summary -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">📈 Academic Performance</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div class="text-center p-4 bg-green-50 rounded-lg">
                    <div class="text-2xl font-bold text-green-600"><?= number_format($stats['average_grade'] ?? 0, 2) ?></div>
                    <div class="text-sm text-green-500">Average Grade</div>
                </div>
                <div class="text-center p-4 bg-blue-50 rounded-lg">
                    <div class="text-2xl font-bold text-blue-600"><?= number_format($stats['highest_grade'] ?? 0, 2) ?></div>
                    <div class="text-sm text-blue-500">Highest Grade</div>
                </div>
                <div class="text-center p-4 bg-yellow-50 rounded-lg">
                    <div class="text-2xl font-bold text-yellow-600"><?= number_format($stats['lowest_grade'] ?? 0, 2) ?></div>
                    <div class="text-sm text-yellow-500">Lowest Grade</div>
                </div>
            </div>
            
            <?php if ($stats['graded_subjects'] > 0): ?>
                <div class="mt-4">
                    <div class="flex justify-between text-sm text-secondary mb-2">
                        <span>Pass Rate</span>
                        <span><?= number_format(($stats['passed_subjects'] / $stats['graded_subjects']) * 100, 1) ?>%</span>
                    </div>
                    <div class="w-full bg-gray-200 rounded-full h-2">
                        <div class="bg-green-500 h-2 rounded-full" style="width: <?= ($stats['passed_subjects'] / $stats['graded_subjects']) * 100 ?>%"></div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Grades Table -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">📋 Grade History</h2>
            <p class="text-sm text-secondary">Complete academic record across all semesters</p>
        </div>
        <div class="card-body">
            <?php if (mysqli_num_rows($grades) > 0): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>School Year</th>
                                <th>Semester</th>
                                <th>Class #</th>
                                <th>Subject Code</th>
                                <th>Description</th>
                                <th>1st Grading</th>
                                <th>2nd Grading</th>
                                <th>3rd Grading</th>
                                <th>Final Grade</th>
                                <th>Remarks</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($g = mysqli_fetch_assoc($grades)): ?>
                                <tr>
                                    <td><?= htmlspecialchars($g['sy']) ?></td>
                                    <td><?= htmlspecialchars($g['sem']) ?></td>
                                    <td><span class="badge badge-primary"><?= $g['cn'] ?></span></td>
                                    <td>
                                        <div class="font-semibold"><?= htmlspecialchars($g['subject_code']) ?></div>
                                    </td>
                                    <td><?= htmlspecialchars($g['description']) ?></td>
                                    <td>
                                        <?php if ($g['g1'] > 0): ?>
                                            <span class="badge badge-<?= $g['g1'] >= 75 ? 'success' : 'danger' ?>">
                                                <?= number_format($g['g1'], 2) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($g['g2'] > 0): ?>
                                            <span class="badge badge-<?= $g['g2'] >= 75 ? 'success' : 'danger' ?>">
                                                <?= number_format($g['g2'], 2) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($g['g3'] > 0): ?>
                                            <span class="badge badge-<?= $g['g3'] >= 75 ? 'success' : 'danger' ?>">
                                                <?= number_format($g['g3'], 2) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($g['final'] > 0): ?>
                                            <span class="badge badge-<?= $g['final'] >= 75 ? 'success' : 'danger' ?>">
                                                <?= number_format($g['final'], 2) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">Not Graded</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($g['remarks']): ?>
                                            <span class="badge badge-<?= $g['remarks'] == 'PASSED' ? 'success' : 'danger' ?>">
                                                <?= htmlspecialchars($g['remarks']) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($g['final'] > 0): ?>
                                            <span class="badge badge-<?= $g['final'] >= 75 ? 'success' : 'danger' ?>">
                                                <?= $g['final'] >= 75 ? '✓ Passed' : '✗ Failed' ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-warning">⏳ In Progress</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <strong>No grades found.</strong> You haven't received any grades yet.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="card mt-6">
        <div class="card-header">
            <h2 class="card-title">⚡ Quick Actions</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <a href="student_subjects.php" class="btn btn-primary">
                    📚 My Subjects
                </a>
                <a href="billing.php" class="btn btn-secondary">
                    💳 View Billing
                </a>
                <a href="exam_permit.php" class="btn btn-outline">
                    📝 Exam Permit
                </a>
                <a href="student_dashboard.php" class="btn btn-outline">
                    🏠 Dashboard
                </a>
            </div>
        </div>
    </div>

    <!-- Grade Information -->
    <div class="card mt-6">
        <div class="card-header">
            <h2 class="card-title">📊 Grading System</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h4 class="font-semibold mb-3">Grade Scale:</h4>
                    <ul class="space-y-2 text-sm text-secondary">
                        <li>• <strong>75.00 - 100.00:</strong> Passed</li>
                        <li>• <strong>Below 75.00:</strong> Failed</li>
                        <li>• <strong>Final Grade:</strong> Average of 3 grading periods</li>
                        <li>• <strong>Grading Periods:</strong> Prelim, Midterm, Final</li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold mb-3">Academic Standing:</h4>
                    <ul class="space-y-2 text-sm text-secondary">
                        <li>• Good standing: No failed subjects</li>
                        <li>• Probation: 1-2 failed subjects</li>
                        <li>• Academic warning: 3+ failed subjects</li>
                        <li>• Consult advisor for academic concerns</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
@media print {
    .card-header button,
    .flex.gap-2 {
        display: none !important;
    }
    
    .card {
        break-inside: avoid;
        page-break-inside: avoid;
    }
    
    .table-responsive {
        overflow: visible !important;
    }
    
    body {
        background: white !important;
    }
}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>