<?php
require_once __DIR__ . '/../includes/header.php';

/* 🔒 SECURITY */
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'student') {
    exit("Access denied");
}

/* ✅ USE REAL student_id */
$student_id = $_SESSION['student_id'] ?? 0;

if (!$student_id) {
    exit("Session error: student_id not set.");
}

/* =========================
   GET STUDENT INFO
========================= */
$student = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT * FROM students 
    WHERE student_id='$student_id'
"));

if (!$student) {
    exit("Student not found");
}

/* =========================
   GET ALL GRADES (ALL SY/SEM)
========================= */
$grades = mysqli_query($conn, "
    SELECT 
        subject_code,
        description,
        cn,
        course,
        sy,
        sem,
        g1,
        g2,
        g3,
        final,
        remarks
    FROM student_subjects
    WHERE student_id='$student_id'
    ORDER BY sy DESC, sem DESC, subject_code ASC
");

if (!$grades) {
    die("Query Error: " . mysqli_error($conn));
}
?>

<h2>My Grades</h2>

<p>
<b><?= $student['fname'] . ' ' . $student['lname'] ?></b><br>
Course: <?= $student['course'] ?><br>
Major: <?= $student['major'] ?>
</p>

<hr>

<table border="1" cellpadding="5">
<tr>
    <th>SY</th>
    <th>SEM</th>
    <th>CN</th>
    <th>Subject</th>
    <th>Description</th>
    <th>1st</th>
    <th>2nd</th>
    <th>3rd</th>
    <th>Final</th>
    <th>Remarks</th>
</tr>

<?php if (mysqli_num_rows($grades) > 0): ?>

    <?php while ($g = mysqli_fetch_assoc($grades)): ?>

    <tr>
        <td><?= $g['sy'] ?></td>
        <td><?= $g['sem'] ?></td>
        <td><?= $g['cn'] ?></td>
        <td><?= $g['subject_code'] ?></td>
        <td><?= $g['description'] ?></td>
        <td><?= $g['g1'] ?></td>
        <td><?= $g['g2'] ?></td>
        <td><?= $g['g3'] ?></td>
        <td><?= $g['final'] ?></td>
        <td><?= $g['remarks'] ?></td>
    </tr>

    <?php endwhile; ?>

<?php else: ?>

<tr>
    <td colspan="10">No grades found.</td>
</tr>

<?php endif; ?>

</table>

<br>

<button onclick="window.print()">Print Grades</button>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>