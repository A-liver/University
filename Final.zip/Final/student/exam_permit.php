<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'student') {
    exit("Access denied");
}

$student_id = $_SESSION['student_id'] ?? 0;
if (!$student_id) exit("Session error");

$student = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT * FROM students WHERE student_id='$student_id'
"));

$sy = $student['sy'];
$sem = $student['sem'];

/* TOTAL BILL */
$subjects = mysqli_query($conn, "
    SELECT units FROM student_subjects
    WHERE student_id='$student_id' AND sy='$sy' AND sem='$sem'
");

$total_units = 0;
while ($s = mysqli_fetch_assoc($subjects)) {
    $total_units += $s['units'];
}

$tuition = ($total_units / 3) * 300;

$billing = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT billing_id FROM billing_master
    WHERE student_id='$student_id' AND sy='$sy' AND sem='$sem'
"));

$billing_id = $billing['billing_id'] ?? 0;

$other_total = 0;

if ($billing_id) {
    $fees = mysqli_query($conn, "
        SELECT amount FROM billing_details WHERE billing_id='$billing_id'
    ");

    while ($f = mysqli_fetch_assoc($fees)) {
        $other_total += $f['amount'];
    }
}

$total_bill = $tuition + $other_total;

/* PAYMENTS */
$paid = 0;

if ($billing_id) {
    $payments = mysqli_query($conn, "
        SELECT amount_paid FROM payments WHERE billing_id='$billing_id'
    ");

    while ($p = mysqli_fetch_assoc($payments)) {
        $paid += $p['amount_paid'];
    }
}

$one_third = $total_bill / 3;

$prelim_ok  = $paid >= $one_third;
$midterm_ok = $paid >= ($one_third * 2);
$final_ok   = $paid >= $total_bill;
?>

<h2>Exam Permit</h2>

<p><?php echo $student['fname']." ".$student['lname']; ?></p>

<hr>

<a href="print_permit.php?type=prelim">
    <button>Prelim Permit</button>
</a>

<a href="print_permit.php?type=midterm">
    <button>Midterm Permit</button>
</a>

<a href="print_permit.php?type=final">
    <button>Final Permit</button>
</a>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>