<?php
require_once __DIR__ . '/../includes/header.php';

/* 🔒 SECURITY CHECK */
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'student') {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username'];

/* GET STUDENT INFO */
$sql = "SELECT * FROM students WHERE email='$username'";
$result = mysqli_query($conn, $sql);
$student = mysqli_fetch_assoc($result);

/* GET USER INFO */
$sql2 = "SELECT * FROM users WHERE username='$username'";
$result2 = mysqli_query($conn, $sql2);
$user = mysqli_fetch_assoc($result2);
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 style="font-size: 2rem; font-weight: 700; background: linear-gradient(135deg, var(--primary-color), var(--primary-dark)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                <i class="fas fa-user-cog"></i> My Profile
            </h1>
            <p class="text-secondary">View and manage your personal information</p>
        </div>
        <div class="flex gap-2">
            <a href="student_dashboard.php" class="btn btn-outline">
                <i class="fas fa-arrow-left"></i> Dashboard
            </a>
        </div>
    </div>

    <?php if ($student): ?>
        <!-- Profile Information -->
        <div class="card mb-6">
            <div class="card-header">
                <h2 class="card-title">
                    <i class="fas fa-user-circle"></i> Personal Information
                </h2>
                <p class="text-sm text-secondary">Your academic and personal details</p>
            </div>
            <div class="card-body">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- Left Column -->
                    <div class="space-y-4">
                        <div class="bg-blue-50 p-4 rounded-lg border border-blue-200">
                            <span class="text-secondary text-sm text-blue-600">Full Name</span>
                            <div class="font-semibold text-blue-800"><?= htmlspecialchars($student['fname'] . " " . $student['lname']) ?></div>
                        </div>
                        <div class="bg-green-50 p-4 rounded-lg border border-green-200">
                            <span class="text-secondary text-sm text-green-600">Course</span>
                            <div class="font-semibold text-green-800"><?= htmlspecialchars($student['course']) ?></div>
                        </div>
                        <div class="bg-purple-50 p-4 rounded-lg border border-purple-200">
                            <span class="text-secondary text-sm text-purple-600">Major</span>
                            <div class="font-semibold text-purple-800"><?= htmlspecialchars($student['major']) ?></div>
                        </div>
                        <div class="bg-orange-50 p-4 rounded-lg border border-orange-200">
                            <span class="text-secondary text-sm text-orange-600">Birthdate</span>
                            <div class="font-semibold text-orange-800"><?= htmlspecialchars($student['bdate']) ?></div>
                        </div>
                    </div>
                    
                    <!-- Right Column -->
                    <div class="space-y-4">
                        <div class="bg-pink-50 p-4 rounded-lg border border-pink-200">
                            <span class="text-secondary text-sm text-pink-600">Gender</span>
                            <div class="font-semibold text-pink-800"><?= htmlspecialchars($student['gender']) ?></div>
                        </div>
                        <div class="bg-indigo-50 p-4 rounded-lg border border-indigo-200">
                            <span class="text-secondary text-sm text-indigo-600">Email</span>
                            <div class="font-semibold text-indigo-800"><?= htmlspecialchars($student['email']) ?></div>
                        </div>
                        <div class="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                            <span class="text-secondary text-sm text-yellow-600">Address</span>
                            <div class="font-semibold text-yellow-800"><?= htmlspecialchars($student['region'] . ", " . $student['city'] . ", " . $student['barangay']) ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Profile Image -->
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">
                    <i class="fas fa-camera"></i> Profile Picture
                </h2>
                <p class="text-sm text-secondary">Your current profile image</p>
            </div>
            <div class="card-body">
                <div class="text-center">
                    <?php if (!empty($student['image_path'])): ?>
                        <img src="/Final/uploads/<?= htmlspecialchars(basename($student['image_path'])) ?>" 
                             alt="Profile Picture" 
                             class="rounded-lg shadow-lg mx-auto" 
                             style="max-width: 200px; height: auto; border: 4px solid var(--primary-color);">
                    <?php else: ?>
                        <div class="bg-gray-100 rounded-lg p-8 inline-block">
                            <i class="fas fa-user-circle text-6xl text-gray-400"></i>
                            <p class="text-gray-500 mt-4">No profile image uploaded</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    <?php else: ?>
        <div class="alert alert-error">
            <i class="fas fa-exclamation-triangle"></i> No student record found.
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>