<?php
require_once __DIR__ . '/../includes/header.php';

/* 🔒 SECURITY */
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'student') {
    header("Location: ../auth/login.php");
    exit();
}

/* ✅ USE REAL STUDENT ID */
if (!isset($_SESSION['student_id'])) {
    die("Session error: student_id not found. Please login again.");
}

$student_id = $_SESSION['student_id'];

/* =========================
   GET STUDENT INFO
========================= */
$result = mysqli_query($conn, "
    SELECT * FROM students WHERE student_id='$student_id'
");

if (!$result) {
    die("Query error: " . mysqli_error($conn));
}

$student = mysqli_fetch_assoc($result);

if (!$student) {
    die("Student record not found.");
}

/* =========================
   OPTIONAL: USER INFO
========================= */
$username = $_SESSION['username'];

$result2 = mysqli_query($conn, "
    SELECT * FROM users WHERE username='$username'
");

$user = mysqli_fetch_assoc($result2);
?>

<h2>Student Dashboard</h2>

<p>
    Welcome: <b><?= $student['fname'] . ' ' . $student['lname'] ?></b><br>
    Student ID: <?= $student_id ?><br>
    Course: <?= $student['course'] ?><br>
    SY: <?= $student['sy'] ?> | SEM: <?= $student['sem'] ?>
</p>

<hr>

<ul>
  <li><a href="student_subjects.php">View Subjects</a></li>
  <li><a href="add_subjects.php">Add Subject</a></li>
<li><a href="grade.php">My Grade</a></li>
  <li><a href="student.php">View Account</a></li>
  <li><a href="billing.php">Billing</a></li>
  <li><a href="exam_permit.php">Exam Permit</a></li>
</ul>

<hr>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>