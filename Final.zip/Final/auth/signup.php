<?php
require_once __DIR__ . '/../includes/init.php';

$error = '';
$success = '';

if (isset($_POST['signup'])) {

    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = md5($_POST['password']);
    $role = $_POST['roles'];
    $status = 'pending';

    $check = mysqli_query($conn, "SELECT * FROM users WHERE username='$username'");

    if (mysqli_num_rows($check) > 0) {
        $error = 'Username already exists!';
    } else {
        $sql = "INSERT INTO users (username, password, role, status)
                VALUES ('$username', '$password', '$role', '$status')";

        if (mysqli_query($conn, $sql)) {
            $success = 'Account created successfully! Please wait for admin approval.';
        } else {
            $error = 'Error creating account: ' . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>University Sign Up</title>
    <link rel="stylesheet" href="/final/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="login-container">
        <div class="login-card fade-in">
            <div class="login-header">
                <div style="font-size: 3rem; margin-bottom: 1rem;">🎓</div>
                <h2>Create Account</h2>
                <p>Register for University Portal access</p>
            </div>

            <?php if (!empty($error)): ?>
                <div class="alert alert-error">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($success)): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <form method="POST" class="text-left">
                <div class="form-group">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" id="username" name="username" class="form-input" placeholder="Enter your username" required>
                </div>

                <div class="form-group">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" id="password" name="password" class="form-input" placeholder="Create a password" required>
                </div>

                <div class="form-group">
                    <label for="roles" class="form-label">Account Type</label>
                    <select id="roles" name="roles" class="form-input" required>
                        <option value="" disabled selected>Select your role</option>
                        <option value="dean">🎓 Dean</option>
                        <option value="teacher">👨‍🏫 Teacher</option>
                        <option value="finance">💰 Finance Officer</option>
                        <option value="cashier">💳 Cashier</option>
                        <option value="records">📋 Registrar</option>
                    </select>
                </div>

                <button type="submit" name="signup" class="btn btn-primary btn-full btn-lg">
                    Create Account
                </button>
            </form>

            <div class="mt-6">
                <div class="alert alert-info">
                    <strong>For Students:</strong> 
                    <a href="../form/eform.php" class="btn btn-outline btn-sm">Click here to enroll as a student</a>
                </div>
            </div>

            <div class="mt-6">
                <p class="text-secondary">
                    Already have an account? 
                    <a href="login.php" class="btn btn-outline btn-sm">Sign In</a>
                </p>
            </div>

            <div class="mt-8">
                <p class="text-secondary text-sm">
                    <strong>Note:</strong> All new accounts require admin approval before login access is granted.
                </p>
            </div>
        </div>
    </div>
</body>
</html>