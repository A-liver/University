<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'finance') {
    exit("Access denied");
}
?>

<h2>Finance Dashboard</h2>

<form method="POST">
    <input type="text" name="student" placeholder="Student Name" required>
    <input type="text" name="sy" placeholder="School Year" required>
    <input type="text" name="sem" placeholder="Semester" required>
    <button name="search">Search</button>
</form>

<hr>

<?php
if (isset($_POST['search'])) {

    $name = mysqli_real_escape_string($conn, $_POST['student']);
    $sy = $_POST['sy'];
    $sem = $_POST['sem'];

    $student = mysqli_fetch_assoc(mysqli_query($conn,
        "SELECT * FROM students 
         WHERE fname LIKE '%$name%' OR lname LIKE '%$name%' 
         LIMIT 1"
    ));

    if (!$student) {
        exit("Student not found");
    }

    $sid = $student['student_id'];

    echo "<h3>{$student['fname']} {$student['lname']}</h3>";

    // ================= STUDENT LOAD =================
    echo "<h4>Student Load</h4>";

    $subjects = mysqli_query($conn,
        "SELECT * FROM student_subjects WHERE student_id='$sid'"
    );

    $units = 0;

    echo "<table border='1'>";
    echo "<tr><th>Subject</th><th>Units</th></tr>";

    while ($s = mysqli_fetch_assoc($subjects)) {
        echo "<tr><td>{$s['subject_code']}</td><td>{$s['units']}</td></tr>";
        $units += $s['units'];
    }

    echo "</table>";
    echo "Total Units: $units<br><br>";

    // ================= FEE SCHEDULE =================
    echo "<h4>Fee Schedule</h4>";

    $fees = mysqli_query($conn, "SELECT * FROM fee_schedules");

    echo "<table border='1'>";
    echo "<tr><th>Fee</th><th>Category</th><th>Amount</th></tr>";

    while ($f = mysqli_fetch_assoc($fees)) {
        echo "<tr>
                <td>{$f['fee_name']}</td>
                <td>{$f['category']}</td>
                <td>{$f['amount']}</td>
              </tr>";
    }

    echo "</table><br>";

    // ================= BILLING =================
    $bm = mysqli_fetch_assoc(mysqli_query($conn,
        "SELECT * FROM billing_master 
         WHERE student_id='$sid' 
         AND school_year='$sy' 
         AND semester='$sem'"
    ));

    if (!$bm) {
        exit("No billing found");
    }

    $bid = $bm['id'];

    $details = mysqli_query($conn, "
        SELECT f.fee_name, f.category, bd.amount
        FROM billing_details bd
        JOIN fee_schedules f ON bd.fee_id = f.fee_id
        WHERE bd.billing_id='$bid'
    ");

    $total = 0;

    echo "<h4>Billing</h4>";
    echo "<table border='1'>";
    echo "<tr><th>Fee</th><th>Amount</th></tr>";

    while ($d = mysqli_fetch_assoc($details)) {

        $amount = $d['amount'];

        if ($d['category'] === 'Tuition') {
            $amount *= $units;
        }

        echo "<tr><td>{$d['fee_name']}</td><td>{$amount}</td></tr>";
        $total += $amount;
    }

    echo "</table>";

    // ================= PAYMENTS =================
    $paid = mysqli_fetch_assoc(mysqli_query($conn,
        "SELECT SUM(amount) AS total 
         FROM payments 
         WHERE student_id='$sid' 
         AND school_year='$sy' 
         AND semester='$sem'"
    ))['total'] ?? 0;

    echo "<p>Total Billing: $total</p>";
    echo "<p>Total Paid: $paid</p>";
    echo "<p><b>Balance: " . ($total - $paid) . "</b></p>";
}
?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>